---
id: K0373
title: 非原始二重点行33本の初出幅は561以上743以下
kind: proposition
status: proved
topics: [geometry, rectangles, variants]
aliases: []
relations:
- type: depends_on
  target: K0001
  note: 標準整数格子の円の定義
artifacts:
- path: research/experiments/fixed-width/reports/nonprimitive-33-double-rows-bounds-20261010.md
  role: proof
  note: 無界な円係数に対する合同必要条件の帰着と有限排除、明示構成
- path: research/experiments/fixed-width/scripts/verify_nonprimitive_33_rows_560.cpp
  role: verifier
  note: 560行での全g=2..17合同必要条件排除（2通りの剰余マスク生成）
- path: research/experiments/fixed-width/output/nonprimitive_33_rows_560_audit.log
  role: data
  note: 全44段階の一致ログ
- path: research/experiments/fixed-width/scripts/check_nonprimitive_33_rows_743.py
  role: verifier
  note: 明示円の整数平方根による独立検査
---

# 非原始二重点行33本の最小幅の新しい上下界

一本の実円が異なる整数点を二つずつ持つ水平行から33本を選び、行番号差のgcdが2以上となる最小連続整数行幅を `F(33)` とする。このとき

\[
\boxed{561\le F(33)\le743}.
\]

下界は、行差g=2..17を尽くし、円の係数を制限しないVieta帰着から平方剰余の必要条件を44段階で完全排除した計算機援用の全称証明。二つのC++実装で各段階が一致した。上界は円 `x²+y²=143650` が幅743内に33本の条件適合行を持つことの直接構成で、Python整数平方根で独立検査した。

**`F(33)` の厳密値は未確定。** 561〜742行の実現可否は未解決。先行の未統合 `F(2)..F(32)` 証明には依存しない。
