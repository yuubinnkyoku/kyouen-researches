---
id: K0373
title: 非原始二重点行33本の最小幅は575以上743以下
kind: proposition
status: proved
topics: [geometry, rectangles, variants]
aliases: []
relations:
- type: depends_on
  target: K0001
  note: 標準整数格子の円の定義
artifacts:
- path: research/experiments/fixed-width/reports/nonprimitive-33-double-rows-bounds-20261010.md
  role: proof
  note: 幅560以下の排除と幅743の明示円
- path: research/experiments/fixed-width/scripts/verify_nonprimitive_33_rows_560.cpp
  role: verifier
  note: 幅560以下での全g=2..17合同必要条件排除
- path: research/experiments/fixed-width/output/nonprimitive_33_rows_560_audit.log
  role: data
  note: 先行の44段階の合同排除ログ
- path: research/experiments/fixed-width/scripts/check_nonprimitive_33_rows_743.py
  role: verifier
  note: 明示円の整数平方根による独立検査
- path: research/experiments/fixed-width/reports/nonprimitive-33-exact-spans-561-574.md
  role: proof
  note: 両端必須の合同条件による幅561〜574の厳密排除
- path: research/experiments/fixed-width/scripts/verify_nonprimitive_33_exact_span.cpp
  role: verifier
  note: 端点条件付き合同排除のC++20二方式
- path: research/experiments/fixed-width/output/f33_exact_spans_561_574.log
  role: data
  note: 全14幅の排除ログ（独立生成2方式で全一致）
---

# 非原始二重点行33本の最小幅の上下界

一本の実円が異なる整数格子点を二つずつ持つ水平行から33本を選び、選択行番号差の最大公約数が2以上となる最小連続整数行幅を `F(33)` とする。このとき

\[
\boxed{575\le F(33)\le743}.
\]

下界は二つの補完的な有限完全排除からなる。まず幅560以下を全g=2..17で合同必要条件により排除する。次に幅561〜574について、選択した最小・最大行を窓の両端に置くとgが幅−1の約数であることを利用し、各幅の全合同候補を排除する。円の係数・半径・横座標を有界化しない。後者の14幅は二方式のC++剰余マスク生成で全ログ一致。前者の証明は別の先行検証記録に依存する。

上界は円 `x²+y²=143650` が幅743内に33本の二重点行を持ち、選択行差のgcdが2である明示構成。整数平方根で独立検証した。

**最小幅そのものは未確定**。幅575〜742の実現可否は未解決であり、幅575の合同排除も完了していない。計算機援用の合同必要条件排除と明示構成を区別し、先行の `F(2)..F(32)` には依存しない。
