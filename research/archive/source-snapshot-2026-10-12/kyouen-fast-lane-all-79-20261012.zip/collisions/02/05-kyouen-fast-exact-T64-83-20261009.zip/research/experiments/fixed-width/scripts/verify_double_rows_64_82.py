#!/usr/bin/env python3
"""Complete modular exclusion for 17 double-hit rows in widths 64..82.
Uses direct square-residue masks and inclusion-maximal intersections.
K0369 (T(63)=16) is the inductive base.
"""
from math import gcd
from time import monotonic
from functools import lru_cache
K=17
MODS=[9,11,7,49,19,23,31,37,41,43,47,53]
@lru_cache(None)
def masks(w,p):
 sq={x*x%p for x in range(p)};out=set()
 for c in range(p):
  z=[(2*y+c)**2%p for y in range(w)]
  for n in range(p):
   m=sum(1<<y for y,t in enumerate(z) if (n-t)%p in sq)
   if m.bit_count()>=K and m&1 and (m>>(w-1))&1:out.add(m)
 return out

def undominated(masks):
 keep=[]
 for m in sorted(set(masks),key=int.bit_count,reverse=True):
  if all((m&a)!=m for a in keep):keep.append(m)
 return keep

def exclude(w,g,verbose=True):
 L=(w-1)//g+1
 states=[(1<<L)-1]
 for p in MODS:
  if gcd(p,g)!=1:continue
  local=undominated(masks(L,p))
  states=undominated(a&b for a in states for b in local if (a&b).bit_count()>=K)
  if verbose:print('CASE',w,g,'MOD',p,'LOCAL',len(local),'STATES',len(states),flush=True)
  if not states:return True
  if len(states)>200000:return False
 return False

for w in range(64,83):
 t=monotonic()
 cases=[g for g in range(1,(w-1)//16+1) if (w-1)%g==0]
 passed=True
 for g in cases:
  if not exclude(w,g,True):passed=False;break
 print('WIDTH',w,'PASS' if passed else 'UNRESOLVED','CASES',cases,'SEC',round(monotonic()-t,3),flush=True)
 if not passed:break

from math import isqrt

def circle_rows(w, c, d):
    result=[]
    for y in range(w):
        disc=1-4*(y*y+c*y+d)
        if disc>0:
            root=isqrt(disc)
            if root*root==disc and root%2==1:
                x1=(-1-root)//2
                x2=(-1+root)//2
                assert x1!=x2
                assert all(x*x+y*y+x+c*y+d==0 for x in (x1,x2))
                result.append(y)
    return result
assert len(circle_rows(63,-47,0))==16
assert circle_rows(83,-105,-6)==[0,1,5,6,9,12,19,23,28,30,42,50,55,63,75,77,82]
print('PASS T(83)=17 via witness and T(82)+1 bound')
