---
id: K0371
title: 二重点行の行差gcdが2以上となる最小幅F(k)を2〜32本すべてで厳密決定
kind: proposition
status: proved
topics: [geometry, rectangles, variants]
aliases: []
relations: []
artifacts:
- path: research/experiments/fixed-width/reports/nonprimitive-double-rows-first-widths-2-32-20261010.md
  role: proof
  note: 無界円係数に対する合同完全排除と30個の明示構成（9本は追加の650円証人）
- path: research/experiments/fixed-width/scripts/verify_nonprimitive_rows_2_32.cpp
  role: verifier
  note: 2方式の平方剰余マスク完全列挙
- path: research/experiments/fixed-width/scripts/check_nonprimitive_rows_2_32.py
  role: verifier
  note: 30個の下界円の整数平方根・行番号差gcdの独立検査
- path: research/experiments/fixed-width/scripts/run_nonprimitive_rows_2_32.py
  role: verifier
  note: 2方式の全出力照合と検査記録の再生成
- path: research/experiments/fixed-width/output/nonprimitive_rows_2_32_audit.csv
  role: data
  note: 有限完全排除のケース数・状態数・ハッシュ
- path: research/experiments/fixed-width/output/nonprimitive_rows_2_32_audit.log
  role: data
  note: 31条件の二方式一致と構成下界の再現ログ
- path: research/experiments/fixed-width/reports/nonprimitive-nine-rows-exact-20261010.md
  role: proof
  note: 残るF(9)=43の全称的な合同排除証明
- path: research/experiments/fixed-width/scripts/verify_nonprimitive_nine_rows.py
  role: verifier
  note: 判別式を直接用いる独立完全列挙
- path: research/experiments/fixed-width/scripts/verify_nonprimitive_nine_rows.cpp
  role: verifier
  note: 平方完成を用いる独立完全列挙
- path: research/experiments/fixed-width/output/nonprimitive_nine_rows_audit.txt
  role: data
  note: 13段階の独立照合ログと整数円の証人
---

一本の実円が整数格子点2個ずつを含む水平行からk本を選び、選択した行番号差の最大公約数をgとする。`g≥2` を実現できる最小の連続整数行幅 `F(k)` は、**2≤k≤32のすべて**について以下の通り。

| k | F(k) |
|---:|---:|
| 2 | 3 |
| 3 | 5 |
| 4 | 7 |
| 5 | 13 |
| 6 | 15 |
| 7 | 21 |
| 8 | 23 |
| 9 | 43 |
| 10 | 45 |
| 11 | 49 |
| 12 | 51 |
| 13 | 85 |
| 14 | 87 |
| 15 | 91 |
| 16 | 95 |
| 17 | 165 |
| 18 | 173 |
| 19 | 187 |
| 20 | 191 |
| 21 | 199 |
| 22 | 201 |
| 23 | 209 |
| 24 | 211 |
| 25 | 421 |
| 26 | 427 |
| 27 | 441 |
| 28 | 451 |
| 29 | 463 |
| 30 | 465 |
| 31 | 469 |
| 32 | 471 |

横座標は全整数を許す。`F(32)=471` は先行する未統合証明の再検査を含む。上界は円の整数根条件から各法の平方剰余必要条件へ帰着し、全g・全局所係数組を有限完全列挙して排除した。下界は8本の整数円から構成し、別実装の整数平方根検査で確認した。数学的帰着＋有限完全排除による全称証明であり、円係数の有限探索ではない。

`F(9)=43` は、従来の幅40排除を幅42へ拡張し、法27と49を含む合同条件で完全排除した結果である。Pythonの判別式直接列挙とC++の平方完成列挙が全13段階で一致した。

この命題は `T(w)` の全円に対する最大値を決定しない。詳細な証拠と信頼境界はproof artifactを参照。
