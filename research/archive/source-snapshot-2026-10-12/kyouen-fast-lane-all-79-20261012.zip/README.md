# 共円ゲーム・高速レーン成果物 全件受け渡しパッケージ

作成日: 2026-10-12

## 収録

- `original-zips/` : **79個の元ZIP**をそのまま無変更で保存（SHA-256は `SHA256SUMS.txt`）。過去の各回の証明、計算コード、検証ログ、knowledge候補を完全保持します。
- `repo-candidates/` : 元ZIP内の `research/...` を抽出し、**内容が競合しない395ファイル**だけを研究リポジトリの相対パスに整列。**監査・正式採用は未完了**です。
- `knowledge-candidates/` : 競合しない候補K項目35ファイルを参考用に隔離。現mainのK番号と衝突するため、**そのままコピーしない**でください。
- `collisions/` : 内容が異なる同名 `research/...` パス5件。勝手に片方を選ばず、版を両方保持しています。
- `manifest.csv` : 元ZIP別のハッシュ・容量・ファイル数。
- `source-members.csv` : 元ZIPの全681ファイルの一覧。
- `repo-paths.csv` : 研究リポジトリ相対パスと収録元の一覧。
- `conflicts.csv` : 同一パス異内容の全対照。

## 推奨導入順

1. まず `original-zips/` が79個あることを確認してください。全件の完全保存はこちらが正本です。
2. `repo-candidates/research/` を**現mainと比較しながら**取り込んでください。現main上に同じパスがある場合は必ず差分を確認してください。単純コピーで上書きしないでください。
3. `collisions/` は複数の研究バージョンがあるため、個別に内容を比較し新しい証拠と古い証拠を必要に応じて統合してください。
4. `knowledge-candidates/` と元ZIPにある `K037x` などは**仮番号**です。2026-10-12時点のmainにはK0380まで使用例があり、同番号の別命題と衝突しています。番号付け直し、schema確認、参照の修正が必要です。
5. 公式 `research/knowledge/items/` に正本を書いてから、`uv sync --locked; uv run --locked python tools/knowledge/check.py; uv run --locked python -m unittest discover -s tools/knowledge/tests; uv run --locked python tools/knowledge/build.py` と変更範囲の回帰テストを実施してください。
6. `research/knowledge/generated/` とroot `README.md` の生成領域は直接編集しないでください。

### 重要な注意

- **このパッケージは「79個の元成果物を漏れなく一括化したもの」であり、「79件の定理が全て証明済み」と保証するものではありません。** 実験、仮説、反例、検証器、仮K項目、以前の研究段階が混在しています。
- `repo-candidates/` は研究リポジトリ配下 `research/` のパスを機械的に収集したもので、参照整合性・新旧優先・現在のmainとの一致までは監査していません。
- 元ZIPの中には `research/` 以外のREADMEや検証器、ログが存在します。それらも必ず `original-zips/` に含まれます。機械抽出だけに頼らず確認してください。
- 一部ZIPにはZIP形式での過去パッケージも入っています。元ZIPを加工せず保存しているため、それらも失われません。
- mainは変更していません。branch/PRも作成していません。
