---
id: K0371
title: 標準整数格子64〜211行の円の二重点行数の厳密最大値
kind: proposition
status: proved
topics: [geometry, rectangles, variants, grundy]
aliases: []
relations:
- type: depends_on
  target: K0369
  note: T(63)=16の帰納基底
- type: depends_on
  target: K0072
  note: 整数円の行分離とq点版への帰結
artifacts:
- path: research/experiments/fixed-width/reports/exact-double-rows-64-211-20261009.md
  role: proof
  note: T(63)=16からの全称帰納・合同完全排除とT(211)=25の証人
- path: research/experiments/fixed-width/scripts/verify_double_rows_64_211.cpp
  role: verifier
  note: 2種類の平方剰余マスク生成法を備えた有限完全排除器
- path: research/experiments/fixed-width/scripts/verify_double_rows_211_witness.py
  role: verifier
  note: 25二重点行の独立整数平方根・円への直接代入検査
---

連続する整数水平行の二重点行最大数 T(w) は、w=64〜82で16、83〜86で17、87〜93で18、94〜95で19、96〜99で20、100で21、101〜104で22、105で23、**106〜210で24**、**211で25** である。横方向の整数座標は全整数を許す。

既存K0369のT(63)=16を唯一の外部帰納基底とし、両端行必須・行番号差gcd・平方剰余必要条件の有限完全排除で全円に対する上界を得る。下界は4本の明示円の整数判別式・直接代入で達成する。191〜210行の20幅は2方式のC++独立列挙で候補0まで照合した。211行では25本の明示円証人とT(210)からの単調性で厳密値を確定した。よって **25本の初達成幅は211行**。

特にT(210)=24なので、標準210×m・q点版はq≥235で全m≥1・全安全局面に対して g(S)=(210min(m,q−1)−|S|) mod2、真の満容量安定化長M=q−1。T(211)=25から同様に211行ではq≥237が十分。これらより小さいqについて行分離が破れるとは主張しない。

本K番号は統合前の仮番号。mainで衝突があれば再採番する。212行以降の厳密値は未確定。
