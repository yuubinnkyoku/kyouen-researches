---
id: K0372
title: 標準整数格子円の二重点行257〜384本を実現する128個の明示構成下界
kind: proposition
status: proved
topics: [geometry, rectangles, variants]
aliases: []
relations: []
artifacts:
- path: research/experiments/fixed-width/reports/double-rows-257-384-20261009.md
  role: proof
  note: 二つの整数円の構成と128件の量化範囲
- path: research/experiments/fixed-width/scripts/construct_double_rows_257_384.py
  role: solver
  note: Gaussian整数の積による有限構成
- path: research/experiments/fixed-width/scripts/verify_double_rows_257_384.py
  role: verifier
  note: 独立した整数平方根による全二重点行の列挙と128件の直接代入
- path: research/experiments/fixed-width/output/double_rows_257_384.csv
  role: data
  note: 257〜384本の128個の円・幅・包含区間
---

# 二重点行257〜384本の構成下界

連続整数水平行0≤y<wのうち一本の実円が相異なる整数格子点を2個持つ行の最大数をT(w)とする。付属CSVの各257≤k≤384について、指定された整数係数円が幅w_kでk本以上の二重点行を持つので、**T(w_k)≥k**である。

構成はノルム6319594450と25764500450の二つのGaussian整数因数分解から得られる。生成器とは独立に、検証器は横座標を直接走査して全行を整数平方根で列挙し、128個の円を整数代入で照合した。量化対象はCSVの128個の明示円・幅であり、任意の円に対する上界・最小達成幅・T(w)の厳密値を主張しない。

先行の97〜256の構成や64〜336の未統合上界証明には依存しない。K番号は統合時の仮番号であり、main上の衝突があれば再採番する。
