---
id: K0371
title: 標準整数格子64〜189行で円が二点ずつ通る行数の厳密最大値
kind: proposition
status: proved
topics: [geometry, rectangles, variants]
aliases: []
relations:
- type: depends_on
  target: K0072
  note: 標準整数格子の二重点行とq点版の独立行帰着
artifacts:
- path: research/experiments/fixed-width/reports/exact-double-rows-64-169.md
  role: proof
  note: 64行基底、65〜169行の端点帰納、24行の明示的整数円
- path: research/experiments/fixed-width/scripts/verify_double_rows_64_169.cpp
  role: verifier
  note: 106幅の完全合同排除、二方式の局所マスク照合、全下界円の検算
- path: research/experiments/fixed-width/scripts/verify_double_rows_64_82.py
  role: verifier
  note: 64〜82行の独立Python合同マスク検証
- path: research/experiments/fixed-width/output/exact_double_rows_64_169.txt
  role: data
  note: 全幅の検証結果と排除に必要な最終法
- path: research/experiments/fixed-width/output/exact_double_rows_64_82_independent.txt
  role: data
  note: Python独立実装による64〜82行の完全検査ログ
- path: research/experiments/fixed-width/reports/exact-double-rows-170-189.md
  role: proof
  note: 170〜189行の端点帰納とg=7の剰余排除
- path: research/experiments/fixed-width/scripts/verify_double_rows_170_189.cpp
  role: verifier
  note: 20幅の完全合同必要条件排除
- path: research/experiments/fixed-width/output/exact_double_rows_170_189.txt
  role: data
  note: 二分割で実行した20幅の検証ログ
- path: research/experiments/fixed-width/scripts/verify_double_rows_170_189_local.py
  role: verifier
  note: 法19の局所上界と24行証人の独立検算（全幅の上界マスクは対象外）
- path: research/experiments/fixed-width/output/exact_double_rows_170_189_local.txt
  role: data
  note: 独立検算の実行結果
scope: 連続する64〜189本の整数水平行、横座標は全整数、一本の実円の二重点行数の最大値
evidence: 数学的な合同必要条件と端点帰納、有限全剰余マスク排除、明示的整数円の直接検証
---

# 64〜189行の厳密二重点行数

`T(w)` は連続する `w` 本の整数水平行で、一本の実円が各行に異なる整数格子点を2個ずつ持つ行数の最大値。

| `w` | `T(w)` |
|---|---:|
| 64〜82 | 16 |
| 83〜86 | 17 |
| 87〜93 | 18 |
| 94〜95 | 19 |
| 96〜99 | 20 |
| 100 | 21 |
| 101〜104 | 22 |
| 105 | 23 |
| 106〜189 | 24 |

169行で初めて現れるg=7は、25行を0,7,...,168に強制してmod19の19剰余対11剰余の矛盾で排除する。上界は二重点行差のgcdによる分母制限、64行でのmod19の例外排除、65〜169行の両端帰納と法9,7,49,11,19,23,31,43等の完全合同排除から得る。下界は64〜82行の16行円と、`x²+y²+x−105y−6=0` の24二重点行の整数平行移動で達成する。64〜169行の106幅と170〜189行の20幅を二つのC++検証器で確認し、局所許容マスクを二方式で照合し、証人の整数根を直接検算した。

任意の `w=189a+b`（`0<=b<189`）で `T(w)<=24a+T(b)`。固定幅q点版では `w=189,q>=214` が全長強解決領域となる。`T(190)` は未確定。数学的帰着と有限完全排除の境界は証明資料に明記した。


## 170〜189行への延長

170〜189行の上界は T(w−1)=24 を仮定した端点帰納により、差のgcdが7以下となることを利用する。g=1,2,4,5は法31まで、g=3,6は法23までで排除し、g=7が候補となる176・183行ではmod19の13剰余対11剰余の矛盾で排除する。証明と再現結果は追加のreport・verifier・outputを参照。

有限窓分割により任意の w=189a+b（0≤b<189）で T(w)≤24a+T(b)。190行は未確定。
