---
id: K0385
title: 任意次元整数直方格子の共線q点組は原始パターンとJordan関数の一次元和で厳密計数できる
kind: proposition
status: proved
topics: [geometry, variants]
aliases: []
relations: []
artifacts:
- path: research/experiments/geometry/reports/box-collinear-all-q-jordan-20261011.md
  role: proof
  note: 全単射による全称証明とJordan関数の展開
- path: research/experiments/geometry/scripts/verify_all_q_collinear_jordan_20261011.py
  role: verifier
  note: 直線列挙1223条件とJordan独立検査4491条件
---

# 任意次元整数直方格子の共線q点組数

任意 d>=1、辺長 n_i>=1、q>=2 の整数直方格子に対して、共線q点組数は
`H_q = (1/2) Σ_{s=1}^{N-1} W_q(s) (∏_i T_i(s)−∏_i n_i)` と厳密に求められる。
ここで `N=max(n_i)`、`T_i(s)=n_i(2L_i+1)−sL_i(L_i+1)`、`L_i=floor((n_i−1)/s)`、
`W_q(s)=Σ_{t|s} μ(s/t) C(t−1,q−2)` である。
`W_q(s)` は端点0,sとともにgcdが1となる内部q−2点の選び方なので非負整数。
q>=3 では W_q は Jordan トーシェント J_k の有理係数一次結合であり、
特に `W_5=(J_3−6J_2+11φ)/6` (s>=2)。

根拠は原始パターンとの全単射による全称証明。有限検算は補助的な独立監査。
既存の高q限定閉公式を一般化する。共円点組数・勝敗には拡張しない。

**統合注意**：これはローカルのK候補であり、mainへの採用時は番号衝突確認、knowledge生成索引の再構築、検査器実行が必要。
