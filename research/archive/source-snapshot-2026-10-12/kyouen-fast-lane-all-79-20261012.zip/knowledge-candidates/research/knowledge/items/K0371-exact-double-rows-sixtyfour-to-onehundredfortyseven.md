---
id: K0371
title: 標準整数格子64〜147行の円の二重点行数の厳密最大値
kind: proposition
status: proved
topics: [geometry, rectangles, variants]
aliases: []
relations:
- type: depends_on
  target: K0369
  note: T(63)=16の帰納基底
- type: depends_on
  target: K0072
  note: 整数格子の円と行独立の帰着
artifacts:
- path: research/experiments/fixed-width/reports/exact-double-rows-64-128-20261009.md
  role: proof
  note: 64〜128の数学的帰着・完全排除・明示円
- path: research/experiments/fixed-width/reports/exact-double-rows-129-147-20261009.md
  role: proof
  note: 129〜147の数学的帰着・完全排除と独立監査
- path: research/experiments/fixed-width/scripts/verify_double_rows_64_95.py
  role: verifier
  note: 64〜95のPython検証器
- path: research/experiments/fixed-width/scripts/verify_double_rows_64_95.cpp
  role: verifier
  note: 64〜95の独立C++検証器
- path: research/experiments/fixed-width/scripts/verify_double_rows_96_128.py
  role: verifier
  note: 96〜128のPython検証器
- path: research/experiments/fixed-width/scripts/verify_double_rows_96_128.cpp
  role: verifier
  note: 96〜128の独立C++検証器
- path: research/experiments/fixed-width/scripts/verify_double_rows_129_147.cpp
  role: verifier
  note: 129〜147の転置型C++検証器
- path: research/experiments/fixed-width/scripts/verify_double_rows_129_147_direct.cpp
  role: verifier
  note: 129〜147の直接平方剰余C++検証器
- path: research/experiments/fixed-width/scripts/verify_double_rows_129_133.py
  role: verifier
  note: 129〜133のPython第三検証器
- path: research/experiments/fixed-width/output/double_rows_129_147_cpp_transposed.txt
  role: data
  note: 19幅175段階の転置型C++出力
- path: research/experiments/fixed-width/output/double_rows_129_147_cpp_direct.txt
  role: data
  note: 19幅175段階の直接型C++出力
---

連続する $w$ 本の整数水平行において、一本の実円が相異なる整数格子点2個ずつを含む行の最大数 $T(w)$ は、

- $T(w)=16$（64〜82）
- $T(w)=17$（83〜86）
- $T(w)=18$（87〜93）
- $T(w)=19$（94〜95）
- $T(w)=20$（96〜99）
- $T(100)=21$
- $T(w)=22$（101〜104）
- $T(105)=23$
- **$T(w)=24$（106〜147）**

である。横方向の整数点は全整数を許す。K0369の $T(63)=16$ を基底とする帰納法と、各円が満たす平方剰余必要条件の有限完全排除で全称上界を証明した。明示円で下界を達成する。円係数の有限範囲探索ではない。

64〜95の249段階、96〜128の211段階を Python と C++ で再照合。129〜147の175段階は二方式のC++で完全一致、129〜133の49段階はPython第三実装でも一致した。

帰結：147行で $q\ge172$ のq点版は全長・全安全局面で行独立となり、$g(S)=(147\min(m,q-1)-|S|)\bmod2$、$M_{147,q}=q-1$。$T(148)$ 以降の厳密値は未確定。証明の根拠・限界は各artifactを参照。
