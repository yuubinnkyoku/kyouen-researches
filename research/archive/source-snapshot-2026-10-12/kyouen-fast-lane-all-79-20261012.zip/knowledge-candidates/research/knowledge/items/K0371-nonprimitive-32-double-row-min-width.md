---
id: K0371
title: 行差gcdが2以上の二重点行32本を実現する最小幅は471
kind: proposition
status: proved
topics: [geometry, rectangles, variants]
aliases: []
relations:
- type: depends_on
  target: K0072
  note: 整数円の二根と合同平方剰余への帰着
artifacts:
- path: research/experiments/fixed-width/reports/gcd32-first-nonprimitive-width-471-20261009.md
  role: proof
  note: 全称帰着と有限完全排除、幅471の明示構成
- path: research/experiments/fixed-width/scripts/verify_double_rows_gcd32_470.cpp
  role: verifier
  note: 2通りの平方剰余マスク生成による37段階の排除
- path: research/experiments/fixed-width/scripts/verify_double_rows_gcd32_471_witness.py
  role: verifier
  note: 円x²+y²=55250の32行と行差gcd2を独立検査
- path: research/experiments/fixed-width/output/gcd32_470_a.txt
  role: data
  note: 37段階の排除結果。b版とSHA-256一致
---

一本の実円が各行に異なる整数格子点2個を持つ32本の整数水平行を選び、その行番号差の最大公約数をgとする。**g≥2の配置を収める最小の連続整数行幅は471**である。

470行の不可能性は選択行の最小値を0に平行移動し、g=2..15の全てについて平方剰余の必要合同条件を有限完全排除する計算機援用証明。471行の実現例は円 x²+y²=55250 で、y=−235..235に32本の二重点行があり、その差のgcdは2。証明・再現手順・検証境界はproof artifactを参照。

この命題は T(470) の厳密値を主張せず、先行のT(64..336)未統合計算にも依存しない。K番号はmain統合時に再確認し、knowledge生成物は再生成すること。
