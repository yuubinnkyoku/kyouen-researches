---
id: K0371
title: 標準整数格子円の二重点行数は64〜82行で16、83行で17
kind: proposition
status: proved
topics: [geometry, rectangles, variants]
aliases: []
relations:
- type: depends_on
  target: K0369
  note: 63行までの厳密値T(63)=16を帰納法の基底に使う
artifacts:
- path: research/experiments/fixed-width/reports/exact-double-rows-64-83-20261009.md
  role: proof
  note: 端点必須帰納法、gcd処理、有限合同排除、83行の証人
- path: research/experiments/fixed-width/scripts/verify_double_rows_64_82.py
  role: verifier
  note: 平方剰余からの直接マスク生成と整数証人の検査
- path: research/experiments/fixed-width/scripts/verify_double_rows_64_82.cpp
  role: verifier
  note: 許容剰余の転置生成による独立C++検証
- path: research/experiments/fixed-width/output/double_rows_64_82_python.txt
  role: data
  note: Python全19幅の合同排除ログ
- path: research/experiments/fixed-width/output/double_rows_64_82_cpp.txt
  role: data
  note: C++全19幅の合同排除ログ
---

標準整数水平行の二重点行数最大値 T(w) は `T(w)=16` (`64<=w<=82`)、`T(83)=17` である。既知の K0369 と合わせて、17本の二重点行を実現する最小の幅は83。

63行までの上界を帰納法の基底とし、17本あるとき両端行必須であることと、行差gcdに基づく必要平方剰余条件を用いる。19幅・41個の候補・161段階を有限完全列挙で排除した。2つの独立実装の各段階の候補数が完全一致。83行では `x²+y²+x−105y−6=0` が17本の二重点行を実現する。

円の中心・半径は無制限。証明の有限部分は合同条件の完全排除であり、有限半径の円探索ではない。84行以上の厳密値は未確定。
