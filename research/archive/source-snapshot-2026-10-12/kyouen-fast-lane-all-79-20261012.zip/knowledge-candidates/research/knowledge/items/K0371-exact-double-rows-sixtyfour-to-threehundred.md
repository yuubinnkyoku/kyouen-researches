---
id: K0371
title: 標準整数格子64〜300行の円の二重点行数の厳密最大値
kind: proposition
status: proved
topics: [geometry, rectangles, variants]
aliases: []
relations:
- type: depends_on
  target: K0369
  note: T(63)=16の基底
- type: depends_on
  target: K0072
  note: 行独立のGrundy公式
artifacts:
- path: research/experiments/fixed-width/reports/exact-double-rows-257-300-20261009.md
  role: proof
  note: 新規44幅の上界帰着・検証と先行256行までの証明依存
- path: research/experiments/fixed-width/scripts/verify_double_rows_257_320.cpp
  role: verifier
  note: 二方式の合同マスク有限完全排除器
- path: research/experiments/fixed-width/scripts/verify_double_rows_257_300_witness.py
  role: verifier
  note: 明示円の整数座標直接列挙
- path: research/experiments/fixed-width/output/double-rows-257-300/transposed-257-280.txt
  role: data
  note: 他3ログと照合した上界排除ログ
---

標準整数格子の連続するw行について、円が2整数点ずつ持つ行の最大数T(w)は以下である（横座標は全整数）。

- 64〜82: 16; 83〜86: 17; 87〜93: 18; 94〜95: 19
- 96〜99: 20; 100: 21; 101〜104: 22; 105: 23
- 106〜210: 24; 211〜213: 25; 214〜220: 26; 221〜225: 27
- 226〜231: 28; 232: 29; 233〜234: 30; 235: 31; 236〜300: 32

本K項目は**統合候補**。64〜256行の未統合先行証明と検証ログを同時に収録するまでmainに追加しないこと。257〜300行の新規44幅は、両端・gcd・合同平方剰余の全称必要条件の有限完全排除を二方式で全537段階一致させ、整数円の32行下界を独立の座標列挙で確認した。形式証明ではない。

帰結：標準整数格子の300×m・q点版はq>=333なら全m>=1・全安全局面で `g(S)=(300 min(m,q−1)−|S|) mod2`、真の満容量安定化長 `M_(300,q)=q−1`。33本を初めて実現できる幅は未確定であり、少なくとも301。
