---
id: K0371
title: 標準整数格子円の二重点行数は64〜95行で厳密に16・17・18・19
kind: proposition
status: proved
topics: [geometry, rectangles, variants]
aliases: []
relations:
- type: depends_on
  target: K0369
  note: T(63)=16 を帰納法の基底に使う
artifacts:
- path: research/experiments/fixed-width/reports/exact-double-rows-64-95-20261009.md
  role: proof
  note: 端点必須帰納法・gcd帰着・合同排除・明示円
- path: research/experiments/fixed-width/scripts/verify_double_rows_64_95.py
  role: verifier
  note: 平方剰余の直接生成による有限完全排除
- path: research/experiments/fixed-width/scripts/verify_double_rows_64_95.cpp
  role: verifier
  note: 転置剰余生成による独立C++検証
- path: research/experiments/fixed-width/output/double_rows_64_95_python.txt
  role: data
  note: Pythonの全幅実行ログ
- path: research/experiments/fixed-width/output/double_rows_64_95_cpp.txt
  role: data
  note: C++の全幅実行ログ
---

連続する w 本の整数水平行で一本の実円が相異なる整数格子点を2個ずつ持つ行数の最大値 T(w) は、`T(w)=16` (`64<=w<=82`)、`T(w)=17` (`83<=w<=86`)、`T(w)=18` (`87<=w<=93`)、`T(w)=19` (`94<=w<=95`) である。横方向の整数点および円の中心・半径に制限はない。

既存の K0369 の T(63)=16 を帰納法の基底とする。各幅で t+1 本の二重点行が存在すれば両端行が必須であることを用い、二重点行差の gcd と合同平方剰余の必要条件へ帰着。必要な幅・g 候補を有限完全列挙で排除した。3つの幅83・87・94では明示円と `T(w)<=T(w-1)+1` から値が増える。Pythonと独立C++の249段階の出力が一致した。

上界は無限個の円を合同条件で一括排除する計算機補助証明であり、有限半径探索ではない。T(96) 以降の厳密値は本項目では未確定。
