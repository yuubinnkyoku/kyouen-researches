---
id: K0371
title: 標準整数格子の円が49〜96本の二重点行を持つ明示的短区間下界
kind: proposition
status: proved
topics:
- geometry
- rectangles
- variants
aliases: []
relations:
- type: depends_on
  target: K0072
  note: 整数格子上の円の二重点行の定義と行独立の幾何
artifacts:
- path: research/experiments/fixed-width/reports/large-double-row-witnesses-49-96.md
  role: proof
  note: 48個の明示的な下界と検証・探索の区別
- path: research/experiments/fixed-width/scripts/verify_large_double_row_windows.py
  role: verifier
  note: 独立した整数平方根検証器
- path: research/experiments/fixed-width/output/bounds_49_96.csv
  role: data
  note: 48個のk・w・ノルム・区間端点
---

標準整数格子の連続する `w` 本の整数水平行で、一本の円が各行に整数格子点2個を持つ最大行数を `T(w)` とする。横方向の整数点は無制限とする。

`research/experiments/fixed-width/output/bounds_49_96.csv` に示した **k=49,...,96 の48個の (k,w) すべてについて T(w)>=k** が成立する。代表値は T(1086)>=49、T(1266)>=64、T(1972)>=65、T(2042)>=72、T(2762)>=73、T(2828)>=80、T(3235)>=81、T(3444)>=96。

各行の証人は `C=-Ylo`、`D=(1+C²-N)/4` とする円 `x²+y²+x−Cy+D=0` である。変数変換 `X=2x+1,Y=2y−C` により `X²+Y²=N` となる。各行について整数平方根で **ちょうどk本**の二重点行を検査し、各行の異なる2格子点を直接代入して照合した。素因数分解に基づく二平方和の全表現数も独立に一致する。

これは明示的な構成下界の数学的証明であり、`T(w)` の厳密最大値や `k` の最小実現幅を全称的に決定したものではない。発見用の有限探索は `N<=50000000` の整数係数円に限定され、全円を網羅しない。
