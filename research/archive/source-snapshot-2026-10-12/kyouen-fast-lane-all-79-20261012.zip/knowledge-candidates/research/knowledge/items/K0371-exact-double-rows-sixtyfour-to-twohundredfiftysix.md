---
id: K0371
title: 標準整数格子64〜256行の円の二重点行数の厳密最大値
kind: proposition
status: proved
topics: [geometry, rectangles, variants]
aliases: []
relations:
- type: depends_on
  target: K0369
  note: T(63)=16を帰納基底とする
- type: depends_on
  target: K0072
  note: 標準整数格子q点版の行独立帰結
artifacts:
- path: research/experiments/fixed-width/reports/exact-double-rows-64-256-20261009.md
  role: proof
  note: 数学的帰着と幅ごとの全称上界・構成下界
- path: research/experiments/fixed-width/scripts/verify_double_rows_64_256.cpp
  role: verifier
  note: 二方式の平方剰余マスク有限完全排除器
- path: research/experiments/fixed-width/scripts/verify_double_rows_212_256_witnesses.py
  role: verifier
  note: 45幅の整数平方根による独立下界照合
- path: research/experiments/fixed-width/output/double-rows-212-256/transposed-212-220.txt
  role: data
  note: 新規45幅のうち最初の9幅の実行ログ。他3区間と直接型は同ディレクトリ
---

連続する `w` 本の標準整数水平行で、一本の実円が異なる整数格子点を2点ずつ持つ行数の最大値 `T(w)` について、既存K0369の `T(63)=16` からの帰納法と合同必要条件の有限完全排除で、64〜256行の厳密値を決定する。**新規範囲は212〜256行**。

- `T(w)=25` (`212<=w<=213`)
- `T(w)=26` (`214<=w<=220`)
- `T(w)=27` (`221<=w<=225`)
- `T(w)=28` (`226<=w<=231`)
- `T(232)=29`
- `T(w)=30` (`233<=w<=234`)
- `T(235)=31`
- `T(w)=32` (`236<=w<=256`)

先行未統合の64〜211行の厳密結果も必要なため、知識統合時にはその証明・検証記録を同時に収録する。新規212〜256行の38幅で必要合同条件を完全排除し、7幅では明示的な円で下界が増加。C++2方式の全430段階一致とPythonの45幅の独立整数検査を記録。数学的帰着と列挙器の健全性はreportを参照。全称命題を有限係数探索から推測したものではない。

帰結：標準整数格子の256×m・q点版で `q>=289` なら全 `m>=1`・全安全局面で `g(S)=(256 min(m,q−1)−|S|) mod2`、真の満容量安定化長 `M_(256,q)=q−1`。`T(257)` 以降と33本の初達成幅は未確定。
