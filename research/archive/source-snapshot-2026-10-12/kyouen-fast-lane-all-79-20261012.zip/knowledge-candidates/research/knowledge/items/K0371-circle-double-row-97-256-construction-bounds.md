---
id: K0371
title: 整数円の二重点行97〜256本の明示的短区間構成下界
kind: proposition
status: proved
topics: [geometry, rectangles, variants]
aliases: []
relations:
- type: depends_on
  target: K0059
  note: 奇二平方和表現数公式
artifacts:
- path: research/experiments/fixed-width/reports/double-rows-97-256-construction-20261009.md
  role: proof
  note: 160個の構成下界の式と適用範囲
- path: research/experiments/fixed-width/scripts/construct_double_rows_97_256.py
  role: verifier
  note: Y座標の整数平方根による全列挙
- path: research/experiments/fixed-width/scripts/verify_double_rows_97_256.cpp
  role: verifier
  note: 独立したX座標の整数平方根による全列挙
- path: research/experiments/fixed-width/output/double_rows_97_256.csv
  role: data
  note: k=97〜256の160構成証人
---

連続するw本の整数水平行に対して、一本の円が異なる整数格子点2個ずつを持つ行数の最大をT(w)とする。付属CSVの160行すべてに対してT(w)≥kが成立する。例えばT(6606)≥97、T(7700)≥128、T(17216)≥160、T(27756)≥192、T(49302)≥256。

証明はN≡2(mod4)の4つの明示的ノルムについて、X²+Y²=Nを満たす奇数座標の解を使い、平行移動した整数円へ埋め込むもの。各円の二重点行の最短区間は有限完全列挙で確認し、独立したX走査・Y走査で照合した。

各幅のT(w)の厳密最大値・最小達成幅は主張しない。K0371はmain上の番号との衝突を統合時に再確認する仮番号である。
