---
id: K0371
title: 標準整数格子64〜168行で円が二点ずつ通る行数の厳密最大値
kind: proposition
status: proved
topics: [geometry, rectangles, variants]
aliases: []
relations:
- type: depends_on
  target: K0072
  note: 標準整数格子の二重点行とq点版の独立行帰着
artifacts:
- path: research/experiments/fixed-width/reports/exact-double-rows-64-168.md
  role: proof
  note: 64行基底、65〜168行の端点帰納、24行の明示的整数円
- path: research/experiments/fixed-width/scripts/verify_double_rows_64_168.cpp
  role: verifier
  note: 105幅の完全合同排除、二方式の局所マスク照合、全下界円の検算
- path: research/experiments/fixed-width/scripts/verify_double_rows_64_82.py
  role: verifier
  note: 64〜82行の独立Python合同マスク検証
- path: research/experiments/fixed-width/output/exact_double_rows_64_168.txt
  role: data
  note: 全幅の検証結果と排除に必要な最終法
- path: research/experiments/fixed-width/output/exact_double_rows_64_82_independent.txt
  role: data
  note: Python独立実装による64〜82行の完全検査ログ
scope: 連続する64〜168本の整数水平行、横座標は全整数、一本の実円の二重点行数の最大値
evidence: 数学的な合同必要条件と端点帰納、有限全剰余マスク排除、明示的整数円の直接検証
---

# 64〜168行の厳密二重点行数

`T(w)` は連続する `w` 本の整数水平行で、一本の実円が各行に異なる整数格子点を2個ずつ持つ行数の最大値。

| `w` | `T(w)` |
|---|---:|
| 64〜82 | 16 |
| 83〜86 | 17 |
| 87〜93 | 18 |
| 94〜95 | 19 |
| 96〜99 | 20 |
| 100 | 21 |
| 101〜104 | 22 |
| 105 | 23 |
| 106〜168 | 24 |

上界は二重点行差のgcdによる分母制限、64行でのmod19の例外排除、65〜168行の両端帰納と法9,7,49,11,19,23,31,43等の完全合同排除から得る。下界は64〜82行の16行円と、`x²+y²+x−105y−6=0` の24二重点行の整数平行移動で達成する。105幅のC++検証器は全法の局所許容マスクを独立二方式で照合し、証人の整数根を直接検算する。

任意の `w=168a+b`（`0<=b<168`）で `T(w)<=24a+T(b)`。固定幅q点版では `w=168,q>=193` が全長強解決領域となる。`T(169)` は未確定。数学的帰着と有限完全排除の境界は証明資料に明記した。
