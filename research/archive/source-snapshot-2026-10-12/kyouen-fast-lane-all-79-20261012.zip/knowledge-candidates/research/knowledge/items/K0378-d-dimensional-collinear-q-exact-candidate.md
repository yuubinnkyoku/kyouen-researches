---
id: K0378
title: 任意次元直方格子の共線q点組数と直線長分布の全称厳密公式
kind: proposition
status: proved
topics: [geometry, statistics]
aliases: []
relations: []
artifacts:
- path: research/experiments/geometry/reports/d-dimensional-collinear-run-identity-20261011.md
  role: proof
  note: 任意次元の原始方向ラン長・二階差分公式とアフィン不変性の全称証明
- path: research/experiments/geometry/scripts/verify_dimensional_collinear_20261011.py
  role: verifier
  note: 点対から直線を独立構築し2〜4次元153条件を照合
- path: research/experiments/geometry/output/d-dimensional-collinear-20261011.txt
  role: data
  note: 153条件の一致と5条件の第三方式照合記録
scope: d>=2の整数直方格子、q>=2の共線点組数と各直線の盤内点数分布
evidence: 原始方向ラン長の二階差分と端点選択による全称数学的証明。独立有限検査153条件。
---

# 任意次元直方格子の共線q点組数と直線長分布の全称厳密公式

原始方向 v（最初の非零成分を正）に対し

`A_k(v)=prod_i max(0,n_i-(k-1)*abs(v_i))`

と置くと、方向 v のちょうど k 点の直線数は

`E_k(v)=A_k(v)-2*A_{k+1}(v)+A_{k+2}(v)`。

したがって共線 q 点組数は

`H_q(B)=sum_v sum_{k>=q} binom(k-2,q-2)*A_k(v)`。

すべて有限和であり、任意の d>=2, q>=2, n_i>=1 について成立する。原始整数方向上の連続点列を数えて二階差分を取る全称証明はartifactにある。非特異アフィン像でも共線性と直線上の点数が保存される。独立点対列挙153条件および直接点組列挙5条件で一致した。

**限界**：超平面・超球面上の点組数や高次元共円ゲームの勝敗ではない。K番号はmain統合時に衝突を再確認する仮番号であり、生成物は未更新。
