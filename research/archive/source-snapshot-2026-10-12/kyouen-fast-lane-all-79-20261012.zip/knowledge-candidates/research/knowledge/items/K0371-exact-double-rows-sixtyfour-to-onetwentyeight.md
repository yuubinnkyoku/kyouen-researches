---
id: K0371
title: 標準整数格子64〜128行で円が二点ずつ通る行数の厳密最大値
kind: proposition
status: proved
topics: [geometry, rectangles, variants]
aliases: []
relations:
- type: depends_on
  target: K0369
  note: T(63)=16 の帰納基底
- type: depends_on
  target: K0072
  note: 標準整数行の円と合同必要条件
artifacts:
- path: research/experiments/fixed-width/reports/exact-double-rows-64-128-20261009.md
  role: proof
  note: 数学的帰納と全称上界への合同完全排除、達成円
- path: research/experiments/fixed-width/scripts/verify_double_rows_64_95.py
  role: verifier
  note: 64〜95の合同条件のPython検証
- path: research/experiments/fixed-width/scripts/verify_double_rows_64_95.cpp
  role: verifier
  note: 64〜95の独立C++検証
- path: research/experiments/fixed-width/scripts/verify_double_rows_96_128.py
  role: verifier
  note: 96〜128の合同条件のPython検証
- path: research/experiments/fixed-width/scripts/verify_double_rows_96_128.cpp
  role: verifier
  note: 96〜128の独立C++検証
- path: research/experiments/fixed-width/output/double_rows_96_128_python.txt
  role: data
  note: 96〜128の全245行の出力
---

連続する w 本の整数水平行において、同じ実円が異なる整数格子点2個ずつを持つ行の最大数 T(w) は

- T(w)=16（64≤w≤82）
- T(w)=17（83≤w≤86）
- T(w)=18（87≤w≤93）
- T(w)=19（94≤w≤95）
- T(w)=20（96≤w≤99）
- T(100)=21
- T(w)=22（101≤w≤104）
- T(105)=23
- T(w)=24（106≤w≤128）

である。横方向の格子点と円の中心・半径は無制限。K0369のT(63)=16を基底に、両端行必須の帰納と平方剰余の有限完全排除で全称上界を証明し、3本の明示円で下界を達成した。64〜95は独立2方式の全249段階、96〜128は独立2方式の全245行で一致した。特に20本〜24本を初めて実現する最小幅は96,100,101,105,106である。証明・検証器・実行結果はartifactを参照。

これは有限個の円係数の探索結果ではなく、数学的帰着と有限完全列挙による全称命題。ただし基底K0369は今回再監査していない。T(129)以降は未確定。
