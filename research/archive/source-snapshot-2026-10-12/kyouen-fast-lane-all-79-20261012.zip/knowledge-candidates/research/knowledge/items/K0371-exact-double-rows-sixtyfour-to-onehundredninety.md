---
id: K0371
title: 標準整数格子64〜190行の円の二重点行数の厳密最大値
kind: proposition
status: proved
topics: [geometry, rectangles, variants, grundy]
aliases: []
relations:
- type: depends_on
  target: K0369
  note: T(63)=16の帰納基底
- type: depends_on
  target: K0072
  note: 整数円の行分離とq点版への帰結
artifacts:
- path: research/experiments/fixed-width/reports/exact-double-rows-64-190-20261009.md
  role: proof
  note: 64〜190行の全称帰納と新規148〜190行の証明
- path: research/experiments/fixed-width/scripts/verify_double_rows_64_190.cpp
  role: verifier
  note: 2種類の独立平方剰余マスク生成法を備えた有限完全排除器
---

連続する整数水平行の二重点行最大数 T(w) は、w=64〜82で16、83〜86で17、87〜93で18、94〜95で19、96〜99で20、100で21、101〜104で22、105で23、**106〜190で24** である。横方向の整数座標は全整数を許す。

既存K0369のT(63)=16を唯一の外部帰納基底として、両端行必須・行番号差gcd・平方剰余必要条件の有限完全排除で全円に対する上界を得る。下界は3本の明示円の整数判別式・直接代入で達成する。148〜190の43幅が今回の新規厳密結果。二方式のC++検証器は全8区間で一致し、171〜177行はPython第三実装とも一致。

特にT(190)=24なので、標準190×m・q点版はq≥215で全m≥1・全安全局面に対して g(S)=(190min(m,q−1)−|S|) mod2、真の満容量安定化長M=q−1。幅191以上の厳密値と25本の初達成幅は未確定。

本K番号は統合前の仮番号。過去の未統合成果物にもK0371候補が存在するため、統合時に内容を照合し、必要なら再採番する。
