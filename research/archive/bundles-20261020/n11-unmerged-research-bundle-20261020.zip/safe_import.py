#!/usr/bin/env python3
"""Read-only comparison by default; --apply creates only files missing in destination."""
from pathlib import Path
import argparse, hashlib, sys
p=argparse.ArgumentParser()
p.add_argument('repo', type=Path)
p.add_argument('--apply', action='store_true')
a=p.parse_args()
source=Path(__file__).resolve().parent/'import_ready'
repo=a.repo.resolve()
if not repo.is_dir() or not (repo/'AGENTS.md').is_file() or not (repo/'.git').exists():
    sys.exit('ERROR: repository directory must contain .git and AGENTS.md')
new=[]; equal=[]; changed=[]
for s in sorted(source.rglob('*')):
    if not s.is_file(): continue
    rel=s.relative_to(source); t=repo/rel
    if t.is_symlink(): changed.append(str(rel)+' (destination is symlink)')
    elif not t.exists(): new.append((s,t))
    elif t.is_file() and hashlib.sha256(s.read_bytes()).digest()==hashlib.sha256(t.read_bytes()).digest():equal.append(str(rel))
    else:changed.append(str(rel))
print(f'New: {len(new)}; already same: {len(equal)}; conflicts: {len(changed)}')
for x in changed:print('CONFLICT',x)
if changed:sys.exit('STOP: conflicts detected, nothing copied; resolve manually')
if not a.apply:
    print('DRY-RUN. Add --apply to copy new files (no commit/push).')
else:
    for s,t in new:
        t.parent.mkdir(parents=True,exist_ok=True)
        with t.open('xb') as dst:dst.write(s.read_bytes())
    print(f'Copied {len(new)} new files, without replacing existing files or committing.')
