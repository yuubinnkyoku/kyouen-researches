# 共円ゲーム11×11：未反映資料まとめ（2026-10-20）

## 確認したmain

- 対象: https://github.com/yuubinnkyoku/kyouen-researches
- 収集時にGitHubで確認した最新main: `2535cf99c9d7ea2322279e0d862e895468a9d91a`
- `AGENTS.md` と `research/knowledge/README.md` を確認済み。
- このZIPを作成しただけで、GitHubへの反映はしていない。

## 重要な注意・訂正

**6石局面 `00000000041000001000401000100000` はWIN**。2026-10-20の旧研究logに「7石子49件のうち45 LOSS・残り4 UNKNOWN」と記した部分は誤り。4件は既知WINであり、`reports/2026-10-20-n11-s6-win-four-s7-correction.md` が訂正文書。元のlogを上書きせず、訂正logを新規追加すること。

**11×11空盤の勝敗はUNKNOWN**。新しい二石rootの確定はない。ここに含まれる数値は各々の限定された証明・探索条件にのみ適用し、未完探索を確定勝敗と解釈しない。

## 内容

- `sources/`: 手元で確認した**全33個の元ZIP**を変更せず収録。旧版も残し検証の経緯を追える。
- `import_ready/research/experiments/`: 特に重要な**9件の実験資料**を展開して配置した統合候補。各実験は名前の異なる専用ディレクトリで保持。`sources/`側の同名ZIPから復元可能。
- `import_ready/research/log/`: 最新の訂正記録（mainへの未反映を確認したもの）。
- `reports/`: 訂正文書と1970局面版の履歴記録。1970版は現在1946版に置き換えられたため、統合候補にはしない。
- `inventory.json` / `inventory.tsv`: 33件すべてのSHA-256、推奨度、内部のファイル数・容量。
- `SHA256SUMS.txt`: 元ZIP33件とレポート2件のSHA-256。
- `safe_import.py`: 反映先を指定して差分候補を検査し、明示した場合のみコピーする補助スクリプト。

A: 訂正や代表証明で最優先（3件）。B: 別主題の証明・計算のため取り込む価値が高い（6件）。H: 履歴資料として原ZIPに保存（24件）。**Hは数学的な結果が偽という意味ではなく、上位版への統合が不完全か重複が多いという意味**。

## 人手で反映する手順

1. このZIPを展開し `inventory.tsv` を確認する。`import_ready` の各実験を現在のmainと比較する。
2. `python3 safe_import.py /path/to/kyouen-researches` でコピー予定と既存ファイルの衝突を調べる。出力は閲覧専用。
3. 合意できれば `python3 safe_import.py /path/to/kyouen-researches --apply` で**新規ファイルのみ**コピーする。既存パスの相違は拒否するので手動で差分確認する。
4. 特に、訂正logを独立に追加し、旧logの誤記を訂正logで参照する。既存研究記録を黙って改変しない。
5. `bash reproduce.sh` を各実験のディレクトリから実行。必要な言語・依存・オプションは各READMEを参照する。`n11-s8-to-s7-lift238` は最新の1946版ZIPを `--archive` で指定する。
6. 証拠の範囲を点検してから、既存K項目を更新するか判断する。自動的にKのstatusを昇格しない。
7. AGENTS.mdが定めるknowledgeのcheck/build/tests、影響するsolver/verifierの回帰を実行する。新branch・PRは作らず、統合するならmainへ直接commitする。

`safe_import.py` は**git commit・pushを実行しない**。中間キャッシュの無条件統合、元の巨大cacheへの上書き、knowledge/generatedの更新を行わない。

## 主な最新版

| 対象 | 同梱資料 |
|---|---|
| 35個の8石LOSSの385葉最小証明 | `n11-s8-compact385-pruned1946-20261020.zip` |
| 8石から7石への逆向き導出 | `n11-s8-to-s7-lift238-20261020.zip` |
| 6石WIN・4件の既知7石WINの独立証明と誤分類訂正 | `n11-s7-four-win-terminal-20261020.zip` |
| 18根の共有証明グラフ | `n11-terminal-dag-1877-20261019.zip` |
| Grundy境界 | `n11-grundy-boundary-20261019.zip` |

## 既存mainに反映済みかどうか

GitHub上の研究記録には、1946局面への圧縮、7石238件の導出などが既にある。一方、関連する完全証明書はこれまで主にLibrary側で保存されており、今回の収集ではGitHubに完全反映されているとは確認できなかった。そのため、**ここでいう「未反映」は厳密なファイル単位の全件差分ではなく、「main未収録と報告された完全資料を含む集合」**。現在のrepoに同一ファイルが存在した場合、補助スクリプトは重複を区別して上書きしない。

## 整合性

- 33個の元ZIPについてCRC検査を完了。
- `inventory.json` のSHA-256で元データが変わっていないことを確認できる。
- 作業用展開にはZIP内の絶対パス・親ディレクトリ脱出・シンボリックリンクは含めない。
- 元ZIPを保存してあるため、今後の整理で証明書・古い不成功実験・補助資料を失わない。
