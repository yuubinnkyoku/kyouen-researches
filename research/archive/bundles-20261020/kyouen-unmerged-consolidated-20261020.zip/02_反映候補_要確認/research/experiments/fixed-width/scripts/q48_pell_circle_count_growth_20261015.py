#!/usr/bin/env python3
"""Independent integer audit of the explicit slope-9 Pell contribution.

The full asymptotic theorem is mathematical; finite tests do not prove it.
"""
from __future__ import annotations

import json
from math import isqrt


def pell_terms_up_to_width(m: int):
    """(n, u_n, v_n, span_n) for all n>=1 with span_n < m."""
    u, v, n = 1, 0, 0
    while True:
        u, v = 19 * u + 60 * v, 6 * u + 19 * v
        n += 1
        span = u + 9 * v
        if span >= m:
            return
        yield n, u, v, span


def count_by_pell(m: int) -> int:
    return 2 * sum(m - span for _, _, _, span in pell_terms_up_to_width(m))


def count_by_span_recurrence(m: int) -> int:
    # Completely separate counting recurrence for the spans, d0=1,d1=73.
    previous, current = 1, 73
    total = 0
    while current < m:
        total += 2 * (m - current)
        previous, current = current, 38 * current - previous
    return total


def verify_geometry(n: int) -> dict:
    u, v = 1, 0
    for _ in range(n):
        u, v = 19 * u + 60 * v, 6 * u + 19 * v
    assert u * u - 10 * v * v == 1
    pts = [(u, 0), (9*v, 0), (5*v-u, 1), (2*u+4*v, 1),
           (4*v-u, 2), (2*u+5*v, 2), (0, 3), (u+9*v, 3)]
    assert len(pts) == len(set(pts)) == 8
    assert min(x for x, _ in pts) == 0
    assert max(x for x, _ in pts) == u + 9*v
    for x, y in pts:
        assert x*x + y*y - (u+9*v)*x - 3*(u*v+1)*y + 9*u*v == 0
    # Independent Vieta verification: common horizontal root sums,
    # and product - y^2 is affine in y.
    by_row = [sorted(x for x, yy in pts if yy == y) for y in range(4)]
    assert all(len(pair) == 2 for pair in by_row)
    assert len({sum(pair) for pair in by_row}) == 1
    p = [pair[0]*pair[1] - y*y for y, pair in enumerate(by_row)]
    assert p[0] - 2*p[1] + p[2] == 0
    assert p[1] - 2*p[2] + p[3] == 0
    return {"n": n, "span": u+9*v, "chords": [pair[1]-pair[0] for pair in by_row]}


def main():
    geometry = [verify_geometry(n) for n in range(1, 9)]
    assert [x['span'] for x in geometry[:5]] == [73, 2773, 105301, 3998665, 151843969]
    samples = [1, 4, 73, 74, 100, 2773, 2774, 105301, 105302,
               1_000_000, 1_000_001, 2_000_001, 3_000_001,
               10**12, 10**30]
    result = []
    for m in samples:
        a, b = count_by_pell(m), count_by_span_recurrence(m)
        assert a == b, (m, a, b)
        # In the exact census range, every nonlocal type is the first
        # three slope-9 Pell terms and its row reflection.
        if m <= 1_000_001:
            expected = 2 * sum(max(0, m - d) for d in (73, 2773, 105301))
            assert a == expected, (m, a, expected)
        result.append({"m": m, "slope9_circles": a,
                       "family_terms": len(list(pell_terms_up_to_width(m)))})
    print(json.dumps({"geometry": geometry, "samples": result,
                      "audit": "PASS"}, indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()
