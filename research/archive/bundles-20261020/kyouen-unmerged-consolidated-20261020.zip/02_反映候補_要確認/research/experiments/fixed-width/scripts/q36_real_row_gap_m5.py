#!/usr/bin/env python3
"""Exact 3x5 q6 row-gap arrangement and game enumeration (no third-party deps)."""
from itertools import combinations,product
from collections import defaultdict,Counter
from fractions import Fraction as F
import json
from pathlib import Path

COLS=5
pairs=defaultdict(list)
for i,j in combinations(range(COLS),2):
    pairs[i+j].append((i,j,i*j))

# Circle equations: B U + A V = 1, U=1/[a(a+b)], V=1/[b(a+b)].
lines=defaultdict(list)
for s, ps in pairs.items():
    for p0,p1,p2 in product(ps,repeat=3):
        A=p2[2]-p1[2]; B=p0[2]-p1[2]
        if max(A,B)<=0: continue
        e=tuple(5*r + c for r,p in enumerate((p0,p1,p2)) for c in p[:2])
        assert len(set(e))==6
        lines[(B,A)].append(tuple(sorted(e)))
for v in lines.values(): assert len(v)==len(set(v))

intersections=set()
for (b,a),(c,d) in combinations(lines,2):
    det=b*d-c*a
    if not det: continue
    u,v=F(d-a,det),F(b-c,det)
    if u>0 and v>0: intersections.add((u,v))

def active(u,v):return {line for line in lines if line[0]*u+line[1]*v==1}

cases={}
cases['off']=(F(1,7),F(1,11))
assert not active(*cases['off'])
for (b,a) in sorted(lines):
    for den in range(3,100):
        if b==0: u,v=F(1,den),F(1,a)
        elif a==0: u,v=F(1,b),F(1,den)
        else: u,v=F(1,den*b),F(den-1,den*a)
        if active(u,v)=={(b,a)}:
            cases[f'line_{b}_{a}']=(u,v);break
    else: raise AssertionError((b,a))
for i,p in enumerate(sorted(intersections)):
    cases[f'cross_{i}']=p

# subset DP, 15 cells. safe iff no hyperedge is subset of mask.
def compute_game(edges):
    edges=[sum(1<<i for i in edge) for edge in edges]
    size=1<<15
    safe=bytearray(size)
    grundy=bytearray(size)
    maximal=Counter()
    safe[0]=1
    for mask in range(1,size):
        lsb=mask & -mask
        p=mask^lsb
        safe[mask]=safe[p] and all((mask&e)!=e for e in edges)
    counts=Counter()
    for mask in range(size-1,-1,-1):
        if not safe[mask]: continue
        reachable=0; num=0
        for i in range(15):
            if mask>>i &1:continue
            next_mask=mask|(1<<i)
            if safe[next_mask]:
                num+=1
                reachable|=1<<grundy[next_mask]
        if not num: maximal[mask.bit_count()]+=1
        g=0
        while reachable>>g&1:g+=1
        grundy[mask]=g
        counts[g]+=1
    return dict(root=grundy[0],safe=sum(safe),max_g=max(counts),g_counts=dict(sorted(counts.items())),maximal=dict(sorted(maximal.items())))

rows=[]
for name,(u,v) in cases.items():
    act=sorted(active(u,v))
    ed=sorted({e for line in act for e in lines[line]})
    game=compute_game(ed)
    rows.append(dict(name=name,U=str(u),V=str(v),a_over_b=str(v/u),line_coefficients=[list(l) for l in act],edges=[list(e) for e in ed],circle_count=len(ed),**game))
print('lines',len(lines),'circle templates',sum(map(len,lines.values())),'intersections',len(intersections),'classes',len(rows))
for r in rows:
 print(r['name'], 'U,V=',r['U'],r['V'],'circles=',r['circle_count'],'g0=',r['root'],'safe=',r['safe'],'maximal=',r['maximal'],'gmax=',r['max_g'])

out=dict(m=5,q=6,columns=list(range(5)),line_coefficients={f'{b},{a}':[list(e) for e in edges] for (b,a),edges in sorted(lines.items())},classes=rows)
with open(Path(__file__).resolve().parent.parent / 'output/q36_real_row_gap_m5.json', 'w') as f:
    json.dump(out,f,indent=2,ensure_ascii=False)
    f.write('\n')
with open(Path(__file__).resolve().parent.parent / 'output/q36_real_row_gap_m5_cases.tsv', 'w') as f:
    for c in rows:
        u,v=F(c['U']),F(c['V'])
        terminal=''.join(f'{k}:{n},' for k,n in c['maximal'].items())
        f.write(f"{c['name']} {u.numerator} {u.denominator} {v.numerator} {v.denominator} {c['circle_count']} {c['safe']} {c['root']} {c['max_g']} {terminal}\n")
