---
id: K0433
title: 非局所4行8点円の奇数分母傾きは法64の強い合同条件を満たす
kind: proposition
status: proved
topics: [geometry, rectangles, variants]
aliases: []
relations:
- type: depends_on
  target: K0431
  note: Pell正規形と非局所円の単調性
- type: depends_on
  target: K0432
  note: 傾きの定義と正規形の一致
artifacts:
- path: research/experiments/fixed-width/reports/q48-mod64-odd-denominator-obstruction-20261015.md
  role: proof
  note: 2進局所分類と3(mod4)素因数障害を組み合わせた全称証明
- path: research/experiments/fixed-width/scripts/q48_mod64_odd_denominator_audit_20261015.py
  role: verifier
  note: 法64平方剰余による独立有限監査
- path: research/experiments/fixed-width/output/q48_mod64_odd_denominator_audit_20261015.txt
  role: data
  note: 有限監査の実行結果
scope: 4連続整数行に各2点を持つ非局所8点円で既約傾きA/BのBが奇数の全ての場合
---

非局所8点円の既約傾き `A/B`（`gcd(A,B)=1`、`A>3B`）において `B` が奇数なら

```
A²−B² ≡ 16 (mod 64),
A²−9B² ≡ 8 (mod 64).
```

特に `P=A²−B²`, `Q=(A²−9B²)/gcd(A,3)²` は `v₂(P)=4`, `v₂(Q)=3` を満たす。

証明は `QM²−PL²=8` を8で割り、`p=P/8≡Q/8+1 (mod8)` を使う。法8の平方剰余から `Q/8≡1,6(mod8)` が必要。後者は `Q` に `3(mod4)` 素因数が現れ、Pell正規形の素因数障害に矛盾する。従って前者のみ。

例：`A/B=63/5` は `P=3944`, `Q=416` で従来の素因数条件を満たすが、法64に反するため実現不能。`A≤1000,B≤200` の既存条件を通過する735組中60組を追加除外した。有限検証は独立した平方剰余集合の計算で行った。十分条件は主張しない。
