---
id: K0436
title: 不等間隔三列・三行の5点円本数とq=5全安全局面Grundyを完全分類
kind: proposition
status: proved
topics: [geometry, rectangles, variants, grundy]
aliases: []
relations: []
artifacts:
- path: research/experiments/fixed-width/reports/three-row-five-circle-and-q5-grundy-20261017.md
  role: proof
  note: 任意の正整数間隔の全称分類と有限mex表
- path: research/experiments/fixed-width/scripts/three_row_five_circle_classification_20261017.py
  role: verifier
  note: 4096盤の独立整数行列式列挙と全安全局面9-bit再帰
- path: research/experiments/fixed-width/output/three_row_five_circle_classification_20261017.txt
  role: data
  note: 4096盤と代表3盤の独立照合結果
scope: 三列x=0,a,a+b・三行y=0,d,2d、正整数a,b,d、q=5完全指摘通常プレイ
---

三列三行の盤上5点円の本数は

\[
N_5=\mathbf1_{a(a+b)=d^2}+\mathbf1_{b(a+b)=d^2}+2\mathbf1_{ab=2d^2}.
\]

三条件は互いに排他的で6点円は存在しない。N5=0,1,2の場合の空盤Grundy値は順に1,0,1。N5=0または1では全安全局面のGrundy値はそれぞれ(9-|S|) mod 2、(8-|S|) mod 2。N5=2では二つの5点禁則の共通2点・各固有3点・自由1点の占有数で全局面を縮約し、82状態の厳密mex表によって強解決する。最大Grundy値は3。

円の本数の式は、二点列の共通縦中心と第三列の円条件による任意の正整数間隔の全称証明。ゲームは全82個数状態のmex再帰で証明。独立した9-bit全安全局面再帰と4096盤の円行列式列挙で検証。一般の盤長や固定幅の真の安定化長を主張しない。
