---
id: K0456
title: 整数格子の11点部分集合で禁止4点組が4個だけでも空盤Grundy値5を実現できる
kind: proposition
status: proved
topics: [geometry, grundy, residual-games, variants]
aliases: []
relations:
- type: depends_on
  target: K0001
  note: 共円または共線4点を禁止する完全指摘規則
- type: depends_on
  target: K0002
  note: 通常プレイのmexとGrundy値
artifacts:
- path: research/experiments/fastlane-four-edge-geometry-20261019/README.md
  role: proof
  note: 11点の明示的整数座標、4本の円方程式、有限完全列挙の説明
- path: research/experiments/fastlane-four-edge-geometry-20261019/verify.py
  role: verifier
  note: 全330組の整数行列式と全2048集合のmex検査
- path: research/experiments/fastlane-four-edge-geometry-20261019/independent.cpp
  role: verifier
  note: 独立の直線・円生成と全局面mex検査
- path: research/experiments/fastlane-four-edge-geometry-20261019/output.json
  role: data
  note: 4禁止組、1635安全局面、Grundy値分布と全初手
scope: 任意の有限整数格子点集合を盤面として許す通常プレイ。具体的な11点集合の空盤についての存在命題。標準n×n盤の残余実現は含まない。
evidence: 11点の整数座標証人、330個の4点組の整数演算による完全検査、2048局面の厳密mex、独立C++方式との一致
---

# 4個の禁止4点組だけでGrundy値5を実現する整数格子配置

整数格子点11個の有限盤面で、禁止4点組がちょうど4個、空盤Grundy値が5となる具体例が存在する。

座標を点番号順に
`(12,8),(-8,0),(2,0),(-2,0),(3,5),(0,4),(0,-4),(24,-16),(12,-4),(24,-4),(12,-16)`
とすると、禁止4点組は
`{0,6,9,10}, {1,2,5,6}, {3,4,5,6}, {7,8,9,10}`
の4個に限られる。空盤からの全11合法手の子Grundy値は
`4,0,0,0,0,2,1,3,3,0,0` であるため、空盤値は5。

330組の持ち上げ行列式と全2048部分集合の完全mex計算で存在を確定し、独立C++の全直線・全円生成による再検査も一致した。安全局面1635個。

これは具体的な整数点部分集合の**存在命題**であり、標準の全格子正方形盤におけるある局面の残余禁止集合がこの4辺になること、また任意の4辺ゲームの幾何的実現可能性を主張しない。
