---
id: K0441
title: 任意の3本の平行直線の6点版は各21候補点で全局面15石偶奇式
kind: proposition
status: proved
topics: [geometry, variants, rectangles, grundy, maximal-safe]
aliases: []
relations: []
artifacts:
- path: research/experiments/three-parallel-lines-q6-20261018/proof.md
  role: proof
  note: 二点和衝突の16上界と任意配置の21候補点定理の全称証明
- path: research/experiments/three-parallel-lines-q6-20261018/verify.py
  role: verifier
  note: 整数行列式による独立幾何監査と二点和上界検算
- path: research/experiments/three-parallel-lines-q6-20261018/results.json
  role: data
  note: 252集合・63504組・36盤・324局面の有限監査結果
scope: 相異なる3本の平行直線上の任意有限候補点集合、各21点以上、q=6完全指摘・通常プレイ
evidence: 任意実数座標での二点和衝突上界と円閉塞の全称証明。有限整数座標の独立監査は補助。
---

# 任意の3本の平行直線の6点版は各21候補点で全局面15石偶奇式

3本の相異なる平行直線それぞれに任意の21個以上の候補点を配置する。各直線内での等間隔性や3直線間での位置合わせは仮定しない。6点共円または共線を禁止する完全指摘・通常プレイで、任意の極大安全集合は各直線5石、合計15石となる。全安全局面Sについて

\[
g(S)=(15-|S|)\bmod2.
\]

不足直線の既存石数をa≤4、残る二直線の石の縦座標集合をB,Cとすると、二点和の一致数 E(B,C)=Σ_s r_B(s)r_C(s)≤16 がその不足直線で円によって塞がれる空点数の上界となる。従って各直線21点以上なら不足直線には必ず合法手がある。全称性は5点集合の二点和衝突が高々3個であることと、各円が不足直線で高々1空点を塞ぐことの数学的証明から従う。

既存K0070の標準整数格子に対するm≥21の解析上界を任意の候補点配置へ拡張する。ただしK0070の標準格子での真の安定化長9を任意配置に主張しない。21がこの一般クラスで最小かは未解決。独立検証の有限標本を無界命題の証明と取り違えない。
