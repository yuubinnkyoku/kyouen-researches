---
id: K0436
title: 共通芯と互いに素な任意個の花弁を持つ禁止集合族の全Grundy閉公式
kind: proposition
status: proved
topics: [grundy, variants, residual-games, maximal-safe]
aliases: []
relations:
- type: depends_on
  target: K0305
  note: 奇数花弁の全局面Grundy偶奇式に用いる一般定理
artifacts:
- path: research/experiments/game-structure/reports/sunflower_grundy_20261018.md
  role: proof
  note: 任意個のsunflower禁止集合の全称証明、極大数と安全局面数
- path: research/experiments/game-structure/scripts/sunflower_grundy_20261018.py
  role: verifier
  note: 実際のビット集合を使った全安全局面の独立mex再帰
- path: research/experiments/game-structure/output/sunflower_grundy_20261018.json
  role: data
  note: 12点以下1470盤・2580974安全局面の完全検証結果
---

# 共通芯と互いに素な任意個の花弁を持つ禁止集合族の全Grundy閉公式

有限点集合を \(C\sqcup P_1\sqcup\cdots\sqcup P_k\sqcup Z\) に分割し、\(C,P_i\ne\varnothing\) とする。極小禁止集合がちょうど \(C\cup P_i\) である通常プレイを考える。安全局面に残る芯点数 \(c\)、花弁点数 \(u_i\)、自由点数 \(z\) とし、\(U=\sum_i u_i\)、\(N=c+U\)、\(m=\min_i u_i\) とする。

全安全局面で \(g(S)=h\oplus(z\bmod2)\) が成立する。\(k\) が奇数なら \(h=(N-1)\bmod2\)。\(k\) が偶数なら \(m<c\) で \(h=(N-1)\bmod2\)、\(m=c\) で \(h=2+(U\bmod2)\)、\(m>c\) で \(h=N\bmod2\)。特に任意の \(k\) で \(g(S)\le3\)。

全称証明は上記reportの帰納法。独立検証は有限範囲に限定される。自由点以外の別禁止集合が存在する残局には直接適用できず、実際の11×11探索の高速化は未測定。
