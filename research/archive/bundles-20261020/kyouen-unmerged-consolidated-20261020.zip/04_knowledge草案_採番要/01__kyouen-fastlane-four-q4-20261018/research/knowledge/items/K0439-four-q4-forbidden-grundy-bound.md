---
id: K0439
title: 禁止集合が4個以下かつ各4点以下のゲームのGrundy値は5以下
kind: proposition
status: proved
topics: [grundy, residual-games, variants]
aliases: []
relations: []
artifacts:
- path: research/experiments/four-q4-residual-grundy-20261018/proof.md
  role: proof
  note: 15所属型への全称帰着、4,079型の完全列挙、最小点数と具体証人
- path: research/experiments/four-q4-residual-grundy-20261018/verify.py
  role: verifier
  note: Pythonの点集合ビットマスクによる完全再帰
- path: research/experiments/four-q4-residual-grundy-20261018/independent.cpp
  role: verifier
  note: C++の未占有所属型数による独立再帰
- path: research/experiments/four-q4-residual-grundy-20261018/results.json
  role: data
  note: 全4,079型のGrundy値分布と証人
scope: 任意有限点集合の通常プレイ禁則完成回避ゲーム。禁止集合は高々4個、各1〜4点。最小点数は相異なる4点禁則が4個の空局面。
evidence: 所属型による有限完全帰着、Python/C++独立完全列挙4,079型の全件一致。格子での幾何実現性は未確認。
---

## 命題・範囲

任意の安全局面で、禁止集合が高々4個かつ各4点以下ならGrundy値は0〜5。
4個の相異なる禁止4点集合の空局面でg=4を実現する最小点数は10、
g=5を実現する最小点数は11。上限5は最良。

## 現在の根拠と限界

4点禁則4個への所属関係15型を使って、全4,079個の整数多重度ベクトルに
全局面のmex再帰を適用した。点集合ビットマスクのPython実装と、
所属型残点数のC++実装が全件一致。禁則の大きさが4未満の場合は、
各禁則を4点へ拡張する補助点を最初から占有させる帰着で証明する。
自由点は独立な単独手として排他的論理和で処理する。

抽象的な禁則ゲームの定理であり、g=5の証人が共円四点組として
実現可能かは未確定。11×11探索の高速化は未測定。

**統合時注意:** K0439は仮番号。mainの番号と衝突したら再採番する。
この項目と実験成果を取り込んだ後、知識生成・検査・単体試験を実行する。
