---
id: K0436
title: 不等間隔3列×4行・6点版の全実数間隔算術分類と全安全局面の強解決
kind: proposition
status: proved
topics: [rectangles, variants, grundy, geometry, maximal-safe]
aliases: []
relations:
- type: depends_on
  target: K0001
  note: 完全指摘ルールと禁止集合の定義
- type: depends_on
  target: K0002
  note: 全安全局面のGrundy値の定義
artifacts:
- path: research/experiments/three-column-four-row-q6-20261018/proof.md
  role: proof
  note: 正実数間隔の全称幾何分類と有限型の完全再帰
- path: research/experiments/three-column-four-row-q6-20261018/verify.py
  role: verifier
  note: 整数行列式の独立幾何判定と4096盤の監査
- path: research/experiments/three-column-four-row-q6-20261018/independent_recurrence.py
  role: verifier
  note: 198安全状態の縮約再帰による独立検算
- path: research/experiments/three-column-four-row-q6-20261018/results.json
  role: data
  note: 4096整数盤の検算結果と3類型の全局面度数
solution:
  board: 不等間隔3列×4行・q=6
  level: strong
  outcome: conditional
  classification: [root, first-moves, all-safe-win-loss, all-safe-grundy]
  coverage: 任意の正実数間隔の全安全局面
  conditions: x=0,a,a+b、y=0,d,2d,3d、a,b,d>0
  verification: [mathematical-proof, exhaustive-enumeration, independent-enumeration]
  certificate: 6点円の全称3条件と225縮約状態の有限完全再帰
  independent_check: 整数4096盤の全6点組判定と198安全状態の別方式再帰
  note: 空盤先手勝ち iff a(a+b)=2d², b(a+b)=2d², ab=2d² のちょうど一つ成立
---

# 不等間隔3列×4行・q=6の完全分類

正実数a,b,d>0の盤で6点円の存在条件は a(a+b)=2d²、b(a+b)=2d²、ab=2d²。ちょうど一条件なら6点円1本で空盤Grundy値1、全12初手が勝ち手、全安全局面のGrundy値は (11−|S|) mod 2。条件なしなら円0本で空盤値0。二条件同時はa=b=dに限り、2本の6点円が2点を共有し空盤値0、全安全局面の最大Grundy値3。

安全局面数は円0,1,2本の順に4096,4032,3972。最後の類型のGrundy度数は(1378,1378,608,608)、極大安全配置は10石16個と11石2個。全称性は円の縦弦の和積方程式と、類型ごとの有限完全再帰から従う。整数4096盤の行列式監査は独立支持資料であって全称証明の代用ではない。

詳細はproof.md参照。既存の等間隔3行q6の結果を不等間隔3列4行へ拡張するが、任意行数の安定化長は主張しない。
