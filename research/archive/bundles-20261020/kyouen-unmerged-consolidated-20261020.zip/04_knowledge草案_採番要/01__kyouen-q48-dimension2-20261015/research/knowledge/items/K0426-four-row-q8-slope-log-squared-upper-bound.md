---
id: K0426
title: 四行8点円の実現可能な既約傾き数は O(H²/(log H)²)
kind: proposition
status: proved
topics: [geometry, rectangles, variants, statistics]
aliases: []
relations: []
artifacts:
- path: research/experiments/fixed-width/reports/q48-slope-dimension-two-sieve-20261015.md
  role: proof
  note: 四剰余類障害と一変数大篩による全称上界
- path: research/experiments/fixed-width/scripts/q48_sieve_dimension2_20261015.py
  role: verifier
  note: 独立した有限範囲の剰余類・因子・篩不等式検査
- path: research/experiments/fixed-width/output/q48_sieve_dimension2_20261015.json
  role: data
  note: H=80,160,320,640の有限監査結果
scope: 四連続整数行に各2点ずつ持つ非局所8点円の既約傾きA/B、1<=A,B<=H
---

四行8点円の実現可能な既約傾きの種類数 R(H) は H→∞ で

\[
R(H)=O\bigl(H^2/(\log H)^2\bigr).
\]

弦長平方の二階差分から得る Pell 型必要条件 `QM²-PL²=8` により、`p>=7, p≡3(mod4), p∤B` なら `A` は法 `p` で `±B,±3B` の4剰余類を避ける。固定 B ごとの一変数大篩を使い、B に依存する分母を乗法的な因子 `F(B)` で抑える。`sum_{B<=H}F(B)=O(H)`、大篩の分母は `G(z)~c(log z)²/2`。従って定理が従う。

全称証明は古典的な一変数大篩と Karamata の Tauber 型定理を使用する。付属の整数監査は有限範囲の独立検査である。合同条件を満たす傾きが実際に8点円を作るとは限らず、対応する下界は未解決。
