---
id: K0454
title: 極小残余禁止辺が二つのときのGrundy値は交差領域の点数で完全に決まる
kind: proposition
status: proved
topics: [grundy, residual-games, search-methods]
aliases: []
relations:
- type: depends_on
  target: K0002
  note: 通常プレイのmexと独立な自由点のxor
- type: depends_on
  target: K0108
  note: 極小残余禁止辺で継続ゲームを表す
artifacts:
- path: research/experiments/game-structure/reports/two-edge-exact-grundy-20261019.md
  role: proof
  note: 全称定理と帰納法による証明
- path: research/experiments/game-structure/scripts/verify_two_edges.py
  role: verifier
  note: 占有subsetによる独立した有限完全mex検査
- path: research/experiments/game-structure/scripts/verify_two_edges.cpp
  role: verifier
  note: 4領域の残数による独立した有限mex検査
- path: research/experiments/game-structure/output/two-edge-exact-grundy-20261019.json
  role: data
  note: 両検査の件数と範囲
scope: 任意有限集合の通常一点追加ゲームで、包含極小残余禁止辺がちょうど2本で比較不能な場合。二辺の対称差と交差および自由点の4領域の点数だけで局面Grundy値を決定する。幾何的共円盤にも適用可能。
evidence: 全ての合法な着手の3領域場合分けと帰納法による数学的全称証明。別状態表現のPython占有subset全1105型、C++残数mex全143960型の独立有限検算。
---

# 二つの極小残余禁止辺のGrundy値

極小禁止辺 E1,E2 の対称差を a=|E1\\E2|, b=|E2\\E1|、交差を c=|E1∩E2|、どちらにも属さない現在合法点を f とし、n=a+b+c+f、m=min(a,b)、M=max(a,b) とする。比較不能なので a,b>=1。

- c=m>0 のとき g=2+((M-c+f) mod 2)。
- c>m のとき g=(n-1) mod 2。
- c<m のとき g=(n-2) mod 2。

従って g>=2 iff c=m>0。g=3 iff c=m>0 かつ M-c+f が奇数。上界3は E1={0,2}, E2={1,2}, V={0,1,2,3} で達成。

自由点をxorで分離し、c=0 と a=0/b=0 を境界として、a,b,c>=1 の場合を c<min、c>min、c=min に分けたmex帰納法で全称証明。独立した有限検算は一般証明の代用ではない。残余辺の構築費用と11×11での実速度改善は未評価。
