import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
const SCRIPT_DIR=path.dirname(fileURLToPath(import.meta.url));
const EXP_DIR=path.resolve(SCRIPT_DIR,'..');
const OUT=path.join(EXP_DIR,'output');
const ROOT=path.resolve(SCRIPT_DIR,'../../../..');
const D=SCRIPT_DIR+path.sep;
const gitBlobSha=b=>crypto.createHash('sha1').update(Buffer.concat([Buffer.from('blob '+b.length),Buffer.from([0]),b])).digest('hex');
const P={
 worklist:'inputs/research/experiments/n11-class2-lane-closability-ranking-20261116/output/class-frontier-remaining-s6-worklist-1410-20261116.csv',
 ledger:'inputs/research/experiments/n11-head1410-partial-parent-nonsterile-children-20261118/output/fold-chain-ledger-1410-1476-crosscheck-20261118.json',
 census:'inputs/research/experiments/n11-head1410-receipt-unclosability-census-20261116/output/n11-head1410-receipt-unclosability-census-20261116.json',
 globalFold:'inputs/research/experiments/n11-s2-5960-ms5-s7-reuse-20261113/output/class-frontier-receipt-harvest-global-fold-20261118.json',
 previousFold:'inputs/research/experiments/n11-s2-5960-ms5-s7-reuse-20261113/output/class-frontier-cost78c-79c-receipts-recompute-20261118.json'
};
const EXPECT={worklist:'2fee1d0718547a62e346d35f5858d7913e37c097',ledger:'e8785d509e8a11a37c0d03cc450455a14708c34d',census:'9c251da3138c5cb0516e097be5e5d0427dfaf5f0',globalFold:'753a4bf4d0e11bea894111f9fa43bcff5e9ab7dc',previousFold:'7e6144cc4bc92c34faa14bed3058cde64fb3880e'};
function need(x,m){if(!x)throw new Error(m);}
function read(k){const b=fs.readFileSync(path.join(ROOT,P[k]));const h=gitBlobSha(b);need(h===EXPECT[k],'input blob mismatch '+k+': '+h);return b;}
function js(k){return JSON.parse(read(k).toString('utf8'));}
const csv=read('worklist').toString('utf8').trim().split(/\r?\n/),cols=csv[0].split(',');
const ix=cols.indexOf('s6_canonical_hex'),cx=cols.indexOf('own_candidates_s6_s7_edge_cost'),kx=cols.indexOf('category');
need(ix>=0&&cx>=0&&kx>=0,'worklist header');
const work=new Map();for(const line of csv.slice(1)){const a=line.split(',');work.set(a[ix],{cost:Number(a[cx]),category:a[kx]});}
const ledger=js('ledger'),census=js('census'),gf=js('globalFold'),prev=js('previousFold');
const coverBytes=fs.readFileSync(path.join(OUT,'five-parent-residual-49-cover-20261119.json'));
const cover=JSON.parse(coverBytes);
const mobilityBytes=fs.readFileSync(path.join(OUT,'49-root-cache-exclusion-mobility-20261119.json'));
const mobility=JSON.parse(mobilityBytes);
const extraction=JSON.parse(fs.readFileSync(path.join(OUT,'first-win7-root-extraction-summary-20261119.json'),'utf8'));
const verification=JSON.parse(fs.readFileSync(path.join(OUT,'first-win7-root-independent-verification-20261119.json'),'utf8'));
const probe1=fs.readFileSync(path.join(OUT,'first-win7-root-probe-andclose1-20261119.jsonl'),'utf8').trim().split(/\r?\n/).map(JSON.parse);
const probe0=fs.readFileSync(path.join(OUT,'first-win7-root-probe-andclose0-20261119.jsonl'),'utf8').trim().split(/\r?\n/).map(JSON.parse);
const bareissLines=fs.readFileSync(path.join(OUT,'first-win7-root-bareiss-subroots-20261119.jsonl'),'utf8').trim().split(/\r?\n/).map(JSON.parse);
const bareissRoot=bareissLines[0],bareiss=bareissLines[1],bareissStats=Object.values(bareiss.stats);
const bareissUnion=JSON.parse(fs.readFileSync(path.join(OUT,'first-win7-root-bareiss-union-audit-20261119.json'),'utf8'));
const root='00000000000000821082000010800000',bit=71;
const item=mobility.mobility.priority_order.find(x=>x.root===root);
const witness=cover.witness.find(x=>x.root===root);
const rootCheck=cover.root_checks.find(x=>x.root===root);
need(item&&witness&&rootCheck,'root missing from pinned 49-root data');
need(item.cache_status==='no-child-orbit-in-published-index'&&item.cache_matches.length===0,'root was not previously cache-unclassified');
need(rootCheck.stones===7&&rootCheck.d4_canonical&&rootCheck.unsafe_quadruples===0,'root geometry precheck');
need(extraction.root===root&&extraction.completed_moves===47&&extraction.legal_next_moves===47&&extraction.fbt_drops===0&&extraction.failure===null,'extraction incomplete/unsafe');
need(verification.verdict==='WIN7 certificate independently verified'&&verification.root_hex===root&&verification.root_safe===true&&verification.root_mobility===47&&verification.subroots_passed===47&&verification.union_missing===0&&verification.union_extra===0,'independent verifier gate');
need(verification.strategy_rows===26708&&verification.consumed_winner_rows===26708&&verification.terminal_range[0]===13&&verification.terminal_range[1]===17,'certificate verifier totals');
need(bareissRoot.stones===7&&bareissRoot.loserMobility===47&&bareiss.rows===26708&&bareissStats.length===47,'Bareiss verifier root/subroots');
const bareissTotals={seen:bareissStats.reduce((s,x)=>s+x.seen,0),terminals:bareissStats.reduce((s,x)=>s+x.terminals,0),opponent_edges:bareissStats.reduce((s,x)=>s+x.opponentEdges,0),terminal_min:Math.min(...bareissStats.map(x=>x.range[0])),terminal_max:Math.max(...bareissStats.map(x=>x.range[1]))};
need(bareissTotals.seen===60884&&bareissTotals.terminals===9942&&bareissTotals.opponent_edges===54552&&bareissTotals.terminal_min===13&&bareissTotals.terminal_max===17,'Bareiss verifier totals');
need(bareissUnion.certificate_rows===26708&&bareissUnion.consumed_unique===26708&&bareissUnion.missing===0&&bareissUnion.extra===0&&bareissUnion.exact_union===true,'Bareiss consumed-union audit');
const cert=fs.readFileSync(path.join(OUT,'win7-root-00000000000000821082000010800000-20261119.n11'));
const certSha=crypto.createHash('sha256').update(cert).digest('hex');
need(certSha===extraction.certificate_sha256,'certificate sha256 mismatch');
const old66=new Set(ledger.derived.closed_rows_66),oldGlobal=new Set(gf.receipts_by_row.map(x=>x.row_hex));
const open0=new Map([...work].filter(([h])=>!old66.has(h)&&!oldGlobal.has(h)));
need(open0.size===6259&&[...open0.values()].reduce((s,x)=>s+x.cost,0)===495507,'global-fold base frontier');
const priorReceiptRows=new Set(prev.new_receipt_coverage.receipts_by_row.map(x=>x.row_hex));
const open=new Map([...open0].filter(([h])=>!priorReceiptRows.has(h)));
need(open.size===6240&&[...open.values()].reduce((s,x)=>s+x.cost,0)===493965,'cost78c/79c fold frontier');
const parents=new Map(census.open_s5_census.map(p=>[p.hex,p]));
const tf=[(x,y)=>[x,y],(x,y)=>[y,10-x],(x,y)=>[10-x,10-y],(x,y)=>[10-y,x],(x,y)=>[10-x,y],(x,y)=>[x,10-y],(x,y)=>[y,x],(x,y)=>[10-y,10-x]];
function d4(m,t){let z=0n;for(let p=0;p<121;p++)if((m>>BigInt(p))&1n){const [x,y]=tf[t](p%11,Math.floor(p/11));z|=1n<<BigInt(11*y+x);}return z;}
function canon(m){let b=null;for(let t=0;t<8;t++){const z=d4(m,t);if(b===null||z<b)b=z;}return b.toString(16).padStart(32,'0');}
function pc(m){let n=0;while(m){m&=m-1n;n++;}return n;}
function rowParents(h){const m=BigInt('0x'+h),ps=new Set();for(let q=0;q<121;q++)if((m>>BigInt(q))&1n){const p=canon(m^(1n<<BigInt(q)));if(parents.has(p))ps.add(p);}return [...ps].sort();}
function demand(h){const d={c1:0,c2:0,c4:0};for(const p of rowParents(h)){const c=parents.get(p).classes;if(c&1)d.c1++;if(c&2)d.c2++;if(c&4)d.c4++;}return d;}
const rootMask=BigInt('0x'+root),rootRows=new Set();
for(let t=0;t<8;t++){const sr=d4(rootMask,t);for(let q=0;q<121;q++)if((sr>>BigInt(q))&1n){const h=canon(sr^(1n<<BigInt(q)));if(open.has(h))rootRows.add(h);}}
const declaredRows=[...witness.rows].sort();
const targetResidual=new Set(cover.receipts.residual_row_hex);
const targetRootRows=new Set([...rootRows].filter(h=>targetResidual.has(h)));
need(targetRootRows.size===2&&JSON.stringify([...targetRootRows].sort())===JSON.stringify(declaredRows),'independent root-to-target-row join mismatch');
for(const h of rootRows)need(open.has(h),'receipt row was already closed or absent');
const closedCost=[...rootRows].reduce((s,h)=>s+open.get(h).cost,0);
const after=new Map(open);for(const h of rootRows)after.delete(h);
const afterCost=[...after.values()].reduce((s,x)=>s+x.cost,0);
function needed(set){let n=0,c=0;for(const h of set.keys())if(demand(h).c1===0){n++;c+=set.get(h).cost;}return {s6_needed_by_open_classes:n,cost_needed_by_open_classes:c};}
const needBefore=needed(open),needAfter=needed(after);
need(needBefore.s6_needed_by_open_classes===4524&&needBefore.cost_needed_by_open_classes===358685,'pre-receipt class-demand control');
const beforeParentRows=new Map([...parents.keys()].map(p=>[p,0]));
const afterParentRows=new Map([...parents.keys()].map(p=>[p,0]));
for(const h of open.keys())for(const p of rowParents(h))beforeParentRows.set(p,beforeParentRows.get(p)+1);
for(const h of after.keys())for(const p of rowParents(h))afterParentRows.set(p,afterParentRows.get(p)+1);
const affected=[...rootRows].flatMap(h=>rowParents(h));
const affectedSet=new Set(affected);
const parentDeltas=[...affectedSet].sort().map(p=>({parent_hex:p,classes:parents.get(p).classes,rows_before:beforeParentRows.get(p),rows_closed:beforeParentRows.get(p)-afterParentRows.get(p),rows_after:afterParentRows.get(p)}));
const remainingParents=[...afterParentRows.values()].filter(n=>n>0).length;
const parentIncidence=[...afterParentRows.values()].reduce((s,n)=>s+n,0);
const frontierBefore=prev.frontier_after;
const frontierAfter={solved_s6_in_manifest:frontierBefore.solved_s6_in_manifest+rootRows.size,remaining_s5_orbits:remainingParents,unique_remaining_s6:after.size,sum_remaining_cost:afterCost,...needAfter,parent_row_incidence:parentIncidence};
need(frontierBefore.solved_s6_in_manifest===1608&&frontierBefore.remaining_s5_orbits===173&&frontierBefore.unique_remaining_s6===6240,'frontier before mismatch');
need(frontierAfter.solved_s6_in_manifest===1612&&frontierAfter.unique_remaining_s6===6236&&frontierAfter.remaining_s5_orbits===173&&frontierAfter.sum_remaining_cost===493703&&frontierAfter.parent_row_incidence===11876,'frontier after count mismatch');
const targetAfter=new Set([...targetResidual].filter(h=>!targetRootRows.has(h)));
const remainingWitness=cover.witness.filter(x=>x.root!==root);
const count=new Map();for(const w of remainingWitness)for(const h of w.rows)count.set(h,(count.get(h)||0)+1);
need(remainingWitness.length===48&&targetAfter.size===95&&count.size===95,'residual cover sizes');
for(const h of targetAfter)need(count.get(h)===1,'residual cover duplicate/missing '+h);
for(const h of count.keys())need(targetAfter.has(h),'residual cover extraneous '+h);
const pairRoots=remainingWitness.filter(w=>w.rows.length===2).length;
const singletonRoots=remainingWitness.filter(w=>w.rows.length===1).length;
need(pairRoots===47&&singletonRoots===1&&Math.ceil(targetAfter.size/2)===48,'residual minimum-cover bound/witness');
const probeVerdicts=[probe1[1],probe0[1]];
need(probe1[0].control==='pilot_d6'&&probe1[0].nodes===3402&&probe0[0].control==='pilot_d6'&&probe0[0].nodes===3402,'runner pilot control');
for(const p of probeVerdicts)need(p.loss===true&&p.capped===false&&p.bit===bit,'runner WIN7-D10 probe');
const record={
 schema:'n11-five-parent-first-win7-receipt-fold-20261119-v1',date:'2026-11-19',status:'fold-complete',source_main_head_before:'7afc92c65fd5cd5d12cc3a092028acc701a7b127',publication_main_head_before_commit:'f4de1d01844d9af2911fac3151b106b3ba67af9d',source_main_at_extraction:extraction.source_main,
 source_blob_pins:{worklist:EXPECT.worklist,ledger:EXPECT.ledger,census:EXPECT.census,global_fold:EXPECT.globalFold,previous_cost78c79c_fold:EXPECT.previousFold,cover_json:gitBlobSha(coverBytes),mobility_json:gitBlobSha(mobilityBytes),runner_v17:'c132cc6425eee3feaeef1d697dd74f968cfedb59',extractor_v16:'5518d375fc6b4a7a14c22a1a65586f0c1c5731c0',bigint_verifier:'62b5d9413daafb172f6e10249976ee6808f7b454',bareiss_verifier:'2960afabdf7c1a7012d223974b65f1423e6890da'},
 root:{hex:root,stones:7,d4_canonical:true,d4_orbit_size:item.root_d4_orbit_size,child_hex:extraction.child,added_bit:bit,legal_next_moves:47,covered_s6_rows:[...rootRows].sort(),covered_five_parent_target_rows:[...targetRootRows].sort(),cache_status_before:'no-child-orbit-in-published-index'},
 search:{engine:'class4_child1_runner_v17.ts',depth:10,cap:950000,andclose_1:{loss:true,nodes:probe1[1].nodes,ms:probe1[1].ms,capped:false,terminal_range:probe1[1].terminalStoneRange},andclose_0:{loss:true,nodes:probe0[1].nodes,ms:probe0[1].ms,capped:false,terminal_range:probe0[1].terminalStoneRange},pilot_d6_controls:[3402,3402]},
 extraction:{engine:'class4_child1_cert_extractor_exact_v16.ts',completed_root_replies:extraction.completed_moves,total_nodes:extraction.total_nodes,unique_strategy_rows:extraction.unique_strategy_rows,fbt_drops:extraction.fbt_drops,terminal_range:extraction.terminal_stone_range,certificate_path:'research/experiments/n11-head1410-residual-cover-after-receipt-fold-20261119/output/win7-root-00000000000000821082000010800000-20261119.n11',certificate_sha256:certSha,certificate_bytes:cert.length},
 independent_verification:{verifier:'verify_win7_certificate_bigint_independent.mjs',method:verification.method,root_safe:verification.root_safe,root_mobility:verification.root_mobility,subroots_passed:verification.subroots_passed,consumed_winner_rows:verification.consumed_winner_rows,union_missing:verification.union_missing,union_extra:verification.union_extra,visited_states_across_subroots:verification.visited_states_across_subroots,winner_states:verification.winner_states,loser_states:verification.loser_states,loser_reply_edges:verification.loser_reply_edges,terminal_count:verification.terminal_count,terminal_range:verification.terminal_range,bareiss_4x4:{root_stones:bareissRoot.stones,root_mobility:bareissRoot.loserMobility,subroots_passed:bareissStats.length,...bareissTotals,consumed_records:bareissUnion.consumed_records,consumed_unique:bareissUnion.consumed_unique,union_missing:bareissUnion.missing,union_extra:bareissUnion.extra}},
 new_receipt_coverage:{unique_s6_rows:rootRows.size,total_row_root_pairs:rootRows.size,closed_edge_cost:closedCost,rows:[...rootRows].sort().map(h=>({row_hex:h,cost:open.get(h).cost,category:open.get(h).category,demand:demand(h),parents:rowParents(h),receipt:{root,verdict:'WIN7-D10',certificate_sha256:certSha}}))},
 parent_deltas:parentDeltas,parent_closure:{fully_closed_parent_count:parentDeltas.filter(p=>p.rows_after===0).length,affected_parent_count:affectedSet.size},
 frontier_before:frontierBefore,frontier_after:frontierAfter,
 five_parent_residual_cover_after:{rows:targetAfter.size,roots:remainingWitness.length,pair_roots:pairRoots,singleton_roots:singletonRoots,maximum_root_span:2,lower_bound:Math.ceil(targetAfter.size/2),witness_size:remainingWitness.length,minimum:true,root_list:remainingWitness.map(x=>x.root),rows_covered:count.size},
 controls:{base_frontier_recomputed:true,root_rows_rederived_from_all_8_d4_images:true,root_target_rows_match_published_49_cover:true,all_global_root_rows_were_open_before_new_receipt:true,root_safe:true,cache_nonmembership_pre_run:true,certificate_sha256_matches:true,all_47_bigint_subroots_verified:true,bigint_union_missing:0,bigint_union_extra:0,all_47_bareiss_subroots_verified:true,bareiss_union_missing:0,bareiss_union_extra:0,residual_48_root_cover_exact:true,win_loss_conflicts:0},
 interpretation_guard:['WIN7-D10 proves a first-player win within depth 10 only from this individual seven-stone root.','The receipt closes two S6 rows in the five-parent residual target; it does not prove a win from the empty board.','REFUTED-D10 remains distinct from LOSS.','The standard 11x11 empty board, two-stone roots {49,60}/{59,60}, S2 {59,60}, and classes 1/2/4 remain UNKNOWN.']
};
fs.writeFileSync(path.join(OUT,'first-win7-root-receipt-fold-20261119.json'),JSON.stringify(record,null,2)+'\n');
console.log(JSON.stringify({status:record.status,rootRows:[...rootRows],closedCost,frontierAfter,residualCover:record.five_parent_residual_cover_after,certificateSha256:certSha},null,2));
