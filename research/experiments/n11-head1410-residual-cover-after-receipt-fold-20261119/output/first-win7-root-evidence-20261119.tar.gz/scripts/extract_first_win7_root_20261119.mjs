import { extractBatch } from '../../n11-s2-5960-ms5-s7-reuse-20261113/scripts/class4_child1_cert_extractor_exact_v16.ts';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';

const SCRIPT_DIR = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(SCRIPT_DIR, '../../../..');
const OUT = path.resolve(SCRIPT_DIR, '../output');
const EXTRACTOR = path.resolve(SCRIPT_DIR, '../../n11-s2-5960-ms5-s7-reuse-20261113/scripts/class4_child1_cert_extractor_exact_v16.ts');
const gitBlobSha = b => createHash('sha1').update(Buffer.concat([Buffer.from('blob ' + b.length), Buffer.from([0]), b])).digest('hex');
const expected = {
  cover: 'a8eaf00bd6494eda50a68e7d06498bed833a7688',
  mobility: 'b35d54a0ced182153802247452a593096a0acf81',
  extractor: '5518d375fc6b4a7a14c22a1a65586f0c1c5731c0'
};
const coverBytes = fs.readFileSync(path.join(OUT, 'five-parent-residual-49-cover-20261119.json'));
const mobilityBytes = fs.readFileSync(path.join(OUT, '49-root-cache-exclusion-mobility-20261119.json'));
const extractorBytes = fs.readFileSync(EXTRACTOR);
for (const [k, b] of Object.entries({cover: coverBytes, mobility: mobilityBytes, extractor: extractorBytes})) {
  if (gitBlobSha(b) !== expected[k]) throw new Error('pinned blob mismatch: ' + k);
}
const cover = JSON.parse(coverBytes.toString('utf8'));
const mobility = JSON.parse(mobilityBytes.toString('utf8'));
const root = '00000000000000821082000010800000';
const bit = 71;
const item = mobility.mobility.priority_order.find(x => x.root === root);
const witness = cover.witness.find(x => x.root === root);
if (!item || !witness) throw new Error('pinned root missing from source data');
const mask = BigInt('0x' + root);
if (((mask >> BigInt(bit)) & 1n) !== 1n) throw new Error('selected bit is not in root');
const child = (mask ^ (1n << BigInt(bit))).toString(16).padStart(32, '0');
const moves = item.legal_bits;
if (moves.length !== item.legal_next_moves || moves.length !== 47) throw new Error('legal-move count mismatch');

const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'n11-win7-extract-'));
const progressPath = path.join(OUT, 'first-win7-root-extraction-progress-20261119.jsonl');
const rowsPath = path.join(tempDir, 'strategy.rows');
const certPath = path.join(OUT, 'win7-root-00000000000000821082000010800000-20261119.n11');
const summaryPath = path.join(OUT, 'first-win7-root-extraction-summary-20261119.json');
fs.writeFileSync(progressPath, '');
fs.writeFileSync(rowsPath, '');
const seen = new Set();
const completed = [];
let totalNodes = 0, minTerm = 121, maxTerm = 0, failure = null;
try {
  for (const move of moves) {
    const t0 = Date.now();
    const r = extractBatch(child, bit, {}, [move]);
    const p = r.perMove?.[String(move)];
    if (r.fatal || !r.rows || !p || !p.ok || p.capped || (r.fbt_drops ?? 0) !== 0) {
      failure = {move, fatal: r.fatal ?? null, perMove: p ?? null, fbt_drops: r.fbt_drops ?? null};
      fs.appendFileSync(progressPath, JSON.stringify({move, status: 'FAIL', ...failure}) + '\n');
      break;
    }
    const fresh = [];
    for (const line of r.rows) if (!seen.has(line)) { seen.add(line); fresh.push(line); }
    if (fresh.length) fs.appendFileSync(rowsPath, fresh.join('\n') + '\n');
    totalNodes += p.nodes;
    if (p.terminalRange) { minTerm = Math.min(minTerm, p.terminalRange[0]); maxTerm = Math.max(maxTerm, p.terminalRange[1]); }
    completed.push(move);
    fs.appendFileSync(progressPath, JSON.stringify({move, status: 'OK', nodes: p.nodes, new_rows: fresh.length, total_rows: seen.size, ms: Date.now() - t0, terminal_range: p.terminalRange, fbt_drops: r.fbt_drops}) + '\n');
  }
  let status = 'INCOMPLETE';
  let certificateSha256 = null;
  if (!failure && completed.length === moves.length) {
    const sorted = [...seen].sort((a, b) => a < b ? -1 : a > b ? 1 : 0);
    const cert = ['n11-terminal-strategy-v1 original_first_WIN7 second_to_move_LOSS', 'root ' + root, ...sorted].join('\n') + '\n';
    fs.writeFileSync(certPath, cert);
    certificateSha256 = createHash('sha256').update(cert).digest('hex');
    status = 'EXTRACTED_UNVERIFIED';
  }
  const summary = {schema: 'n11-win7-d10-certificate-extraction-v1', source_main: '567045d818d1943bfb8b97d74e7f9bc29f9d0acd', root, child, added_bit: bit, covered_rows: witness.rows, legal_next_moves: moves.length, completed_moves: completed.length, completed_move_list: completed, total_nodes: totalNodes, unique_strategy_rows: seen.size, terminal_stone_range: completed.length ? [minTerm, maxTerm] : null, fbt_drops: failure?.fbt_drops ?? 0, failure, status, certificate_sha256: certificateSha256};
  fs.writeFileSync(summaryPath, JSON.stringify(summary, null, 2) + '\n');
  console.log(JSON.stringify(summary));
  if (status !== 'EXTRACTED_UNVERIFIED') process.exitCode = 1;
} finally {
  fs.rmSync(tempDir, {recursive: true, force: true});
}
