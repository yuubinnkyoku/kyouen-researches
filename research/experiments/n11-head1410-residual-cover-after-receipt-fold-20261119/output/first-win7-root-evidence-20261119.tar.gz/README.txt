N11 first residual-root WIN7-D10 evidence bundle (2026-11-19)

This archive contains the extraction, independent-verification, and receipt-fold drivers plus their machine-readable outputs. It intentionally does not duplicate the large certificate; the adjacent file win7-root-00000000000000821082000010800000-20261119.n11.gz stores it.

Extract this archive at the experiment directory root so that scripts/ and output/ are restored. Then decompress the certificate:

  gzip -dk output/win7-root-00000000000000821082000010800000-20261119.n11.gz

The repository must also contain the pinned source files and inputs referenced by the scripts (the existing n11-s2-5960-ms5-s7-reuse-20261113 scripts, the 49-root cover/mobility outputs, worklist, ledger, census, and prior receipt folds).

To regenerate the certificate:

  node --experimental-strip-types scripts/extract_first_win7_root_20261119.mjs

To run both independent verifiers:

  node scripts/verify_first_win7_root_20261119.mjs

To recompute the receipt fold and exact 48-root residual cover:

  node scripts/fold_first_win7_root_receipt_20261119.mjs

The extraction progress JSONL includes elapsed milliseconds and is observational; those timing fields are not expected to be byte-identical on replay. The certificate, extraction summary, verifier outputs, and receipt-fold result are deterministic for the pinned inputs.
